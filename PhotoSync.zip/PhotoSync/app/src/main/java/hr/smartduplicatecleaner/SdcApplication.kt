package hr.smartduplicatecleaner

import android.app.Application
import android.content.Context
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import hr.smartduplicatecleaner.data.ResultsRepository
import hr.smartduplicatecleaner.data.RoomHashCache
import hr.smartduplicatecleaner.data.db.AppDatabase
import hr.smartduplicatecleaner.data.settings.FeatureSettingsRepository
import hr.smartduplicatecleaner.data.settings.SettingsRepository
import hr.smartduplicatecleaner.transfer.TransferManager
import hr.smartduplicatecleaner.deletion.DeletionManager
import hr.smartduplicatecleaner.scan.ScanManager

/** Jednostavan ručni "DI" spremnik – jedna instanca svake usluge za cijelu aplikaciju. */
class AppContainer(val context: Context) {
    val database: AppDatabase = AppDatabase.create(context)
    val settings = SettingsRepository(context)
    val results = ResultsRepository(database)
    val hashCache = RoomHashCache(database)
    val scanManager = ScanManager(context, settings, results, hashCache)
    val deletionManager = DeletionManager(context, database)
    val features = FeatureSettingsRepository(context)
    val transferManager = TransferManager(context, features)
}

class SdcApplication : Application(), ImageLoaderFactory {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }

    /** Coil: minijature fotografija i sličice iz videozapisa, uz ograničenu predmemoriju. */
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .components { add(VideoFrameDecoder.Factory()) }
        .crossfade(true)
        .build()
}
