package hr.smartduplicatecleaner.scan

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import hr.smartduplicatecleaner.MainActivity
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.SdcApplication
import hr.smartduplicatecleaner.core.scan.ScanPhase
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Usluga u prvom planu (dataSync) koja drži proces aktivnim dok traje skeniranje
 * i prikazuje napredak u obavijesti s gumbom za otkazivanje.
 */
class ScanService : LifecycleService() {

    private val manager get() = (application as SdcApplication).container.scanManager
    private var lastUpdate = 0L
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        // Djelomični wake lock: procesor radi i kad je zaslon ugašen. Ograničen na 3 sata kao zaštita baterije.
        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DuplicateCleaner:scan")
            .apply { setReferenceCounted(false); acquire(3 * 60 * 60 * 1000L) }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, build(getString(R.string.notif_scanning), null), type)
        lifecycleScope.launch {
            manager.state.collectLatest { state ->
                when (state) {
                    is ScanState.Running -> update(state)
                    else -> stopSelfNow()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_CANCEL) manager.cancel()
        if (!manager.isRunning && manager.state.value !is ScanState.Running) stopSelfNow()
        return START_NOT_STICKY
    }

    /** Android 15: vremensko ograničenje za dataSync uslugu – usluga se mora zaustaviti. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        stopSelfNow()
    }

    private fun update(state: ScanState.Running) {
        val now = System.currentTimeMillis()
        if (now - lastUpdate < 700) return
        lastUpdate = now
        val p = state.progress
        val text = when (p?.phase) {
            ScanPhase.LISTING -> getString(R.string.phase_listing) + " · " + p.filesFound
            ScanPhase.HASHING -> getString(R.string.phase_hashing) + " · " + p.processed + "/" + p.total
            ScanPhase.ANALYZING_IMAGES -> getString(R.string.phase_images) + " · " + p.processed + "/" + p.total
            ScanPhase.GROUPING -> getString(R.string.phase_grouping)
            else -> getString(R.string.notif_scanning)
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, build(text, p?.let { if (it.total > 0) it.processed * 100 / it.total else null }))
    }

    private fun build(text: String, percent: Int?) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.stat_notify_sync)
        .setContentTitle(getString(R.string.app_name))
        .setContentText(text)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setProgress(100, percent ?: 0, percent == null)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE
            )
        )
        .addAction(
            0, getString(R.string.cancel),
            PendingIntent.getService(
                this, 1, Intent(this, ScanService::class.java).setAction(ACTION_CANCEL),
                PendingIntent.FLAG_IMMUTABLE
            )
        )
        .build()

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun stopSelfNow() {
        releaseWakeLock()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    override fun onDestroy() {
        releaseWakeLock()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "scan"
        private const val NOTIFICATION_ID = 42
        private const val ACTION_CANCEL = "hr.smartduplicatecleaner.CANCEL_SCAN"

        @Suppress("unused")
        fun stop(context: Context) = context.stopService(Intent(context, ScanService::class.java))
    }
}
