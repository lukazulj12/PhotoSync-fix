package hr.smartduplicatecleaner.transfer

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.exifinterface.media.ExifInterface
import hr.smartduplicatecleaner.core.media.Mp4Dates
import hr.smartduplicatecleaner.datefix.DateWriter
import hr.smartduplicatecleaner.BuildConfig
import hr.smartduplicatecleaner.core.logic.FileClassifier
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.model.SourceType
import hr.smartduplicatecleaner.core.scan.CancelToken
import hr.smartduplicatecleaner.core.scan.FileSource
import hr.smartduplicatecleaner.core.transfer.IncomingFile
import hr.smartduplicatecleaner.core.transfer.TransferCategory
import hr.smartduplicatecleaner.core.transfer.TransferClassifier
import hr.smartduplicatecleaner.core.transfer.TransferItem
import hr.smartduplicatecleaner.core.transfer.TransferSink
import hr.smartduplicatecleaner.core.transfer.TransferSource
import hr.smartduplicatecleaner.storage.FileSystemSource
import hr.smartduplicatecleaner.storage.MediaStoreSource
import hr.smartduplicatecleaner.storage.SafTreeSource
import hr.smartduplicatecleaner.storage.StorageAccess
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/** Popis datoteka za slanje prema odabranim vrstama i vremenskom intervalu. */
object TransferScanner {

    fun scan(
        context: Context,
        categories: Set<TransferCategory>,
        from: Long?,
        to: Long?,
        safTrees: Set<String>
    ): List<TransferItem> {
        val sources = mutableListOf<FileSource>()
        val media = buildSet {
            if (TransferCategory.PHOTOS in categories) add(FileCategory.IMAGE)
            if (TransferCategory.VIDEOS in categories) add(FileCategory.VIDEO)
            if (TransferCategory.AUDIO in categories) add(FileCategory.AUDIO)
        }
        if (media.isNotEmpty()) sources += MediaStoreSource(context, media)
        val wantsFiles = categories.any { it != TransferCategory.APPS }
        if (wantsFiles && StorageAccess.hasAllFilesAccess()) sources += FileSystemSource(context)
        if (wantsFiles) safTrees.forEach { sources += SafTreeSource(context, it) }

        val unique = LinkedHashMap<String, ScannedFile>()
        for (s in sources) {
            try {
                s.enumerate(CancelToken.NONE, { f -> unique.putIfAbsent(f.key, f) }, { })
            } catch (e: Exception) {
                // Izvor bez dopuštenja ili nedostupan – preskače se.
            }
        }
        val result = mutableListOf<TransferItem>()
        for (f in unique.values) {
            if (f.sizeBytes <= 0) continue
            val cat = TransferClassifier.of(f)
            if (cat !in categories) continue
            val created = listOfNotNull(f.dateTakenMillis, f.dateModifiedMillis).filter { it > 0 }.minOrNull()
            if ((from != null || to != null) && (created == null || (from != null && created < from) || (to != null && created > to))) continue
            result += TransferItem(
                id = result.size,
                relativeDir = f.relativeDir,
                name = f.name,
                size = f.sizeBytes,
                modified = f.dateModifiedMillis,
                taken = f.dateTakenMillis,
                category = cat,
                mime = f.mimeType,
                sourceRef = if (f.source == SourceType.FILE_SYSTEM) f.absolutePath ?: f.uri else f.uri
            )
        }
        if (TransferCategory.APPS in categories) result += apps(context, startId = result.size)
        return result
    }

    /**
     * Instalirane aplikacije (one s ikonom u izborniku, bez sistemskih). Kopiraju se njihove APK datoteke
     * (uključujući dijelove "split APK"); podaci aplikacija ne mogu se prenijeti (Androidova zaštita).
     */
    @Suppress("DEPRECATION")
    fun apps(context: Context, startId: Int): List<TransferItem> {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val packages = pm.queryIntentActivities(launcher, 0).map { it.activityInfo.packageName }.distinct()
        val result = mutableListOf<TransferItem>()
        var id = startId
        for (pkg in packages) {
            if (pkg == context.packageName) continue
            val ai = try { pm.getApplicationInfo(pkg, 0) } catch (e: Exception) { continue }
            val system = ai.flags and ApplicationInfo.FLAG_SYSTEM != 0 && ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP == 0
            if (system) continue
            val label = safeName(ai.loadLabel(pm).toString()).ifEmpty { pkg }
            val files = listOfNotNull(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())
            val single = files.size == 1
            for (path in files) {
                val f = File(path)
                if (!f.canRead()) continue
                val name = if (single) "$label.apk" else if (path == ai.sourceDir) "base.apk" else f.name
                result += TransferItem(
                    id = id++,
                    relativeDir = if (single) "Apps/" else "Apps/$label/",
                    name = name,
                    size = f.length(),
                    modified = f.lastModified(),
                    taken = null,
                    category = TransferCategory.APPS,
                    mime = APK_MIME,
                    sourceRef = path
                )
            }
        }
        return result
    }

    private fun safeName(s: String) = s.replace(Regex("[\\\\/:*?\"<>|\\u0000]"), "_").trim()

    const val APK_MIME = "application/vnd.android.package-archive"
}

/** Čitanje datoteka na pošiljatelju (MediaStore/SAF URI ili putanja). */
class AndroidTransferSource(private val context: Context) : TransferSource {
    override fun open(item: TransferItem): InputStream {
        val ref = item.sourceRef
        if (!ref.startsWith("content://")) return FileInputStream(File(ref))
        var uri = Uri.parse(ref)
        // Izvorni bajtovi fotografija i videozapisa (uključujući lokaciju u EXIF-u), ako je dopušteno.
        if (uri.authority == MediaStore.AUTHORITY && StorageAccess.hasMediaLocation(context) &&
            (item.category == TransferCategory.PHOTOS || item.category == TransferCategory.VIDEOS)
        ) {
            try { uri = MediaStore.setRequireOriginal(uri) } catch (e: Exception) { }
        }
        return try {
            context.contentResolver.openInputStream(uri) ?: throw IOException("open")
        } catch (e: UnsupportedOperationException) {
            context.contentResolver.openInputStream(Uri.parse(ref)) ?: throw IOException("open")
        } catch (e: SecurityException) {
            context.contentResolver.openInputStream(Uri.parse(ref)) ?: throw IOException("open")
        }
    }
}

/** Primljena aplikacija (APK datoteke) – za instalaciju nakon prijenosa. */
data class ReceivedApp(val label: String, val apks: List<Uri>)

/** Postavke spremanja primljenih datoteka. */
data class ReceiveOptions(
    val skipExisting: Boolean,
    /** Spremi u mapu istog naziva (ista putanja kao na starom mobitelu) ako na ovom mobitelu postoji. */
    val sameFolders: Boolean,
    /** Ručno odabrana mapa (SAF URI) za datoteke kojima ne postoji ista mapa; null = zadana mapa aplikacije. */
    val customTree: String?,
    /** Unutar mape vrste zadrži naziv izvorne mape (npr. PhotoSync/Fotografije/Camera). */
    val keepSubfolders: Boolean,
    /** Naziv podmape za vrstu (Fotografije, Videozapisi…). */
    val folderName: (TransferCategory) -> String
)

/**
 * Spremanje primljenih datoteka.
 *
 * Redoslijed odredišta:
 *  1. (opcija) ista mapa kao na starom mobitelu, ako na ovom postoji – npr. DCIM/Camera, Pictures/Screenshots
 *  2. inače zadana mapa aplikacije s podmapom za svaku vrstu (PhotoSync/Fotografije, PhotoSync/Videozapisi …)
 *     ili ručno odabrana mapa (također s podmapama po vrsti)
 *
 * Zadana mapa: uz "Pristup svim datotekama" /Interna memorija/PhotoSync, inače /Interna memorija/Download/PhotoSync
 * (Androidova pravila dopuštaju aplikacijama sve vrste datoteka samo u mapi Download).
 * Izvorni datum se čuva gdje god je moguće (datum izmjene; fotografijama/videozapisima bez datuma snimanja
 * izvorni datum se upisuje u EXIF / MP4).
 */
class AndroidTransferSink(private val context: Context, private val opt: ReceiveOptions) : TransferSink {
    private val resolver get() = context.contentResolver
    private val direct = StorageAccess.hasAllFilesAccess()
    private val root: File = Environment.getExternalStorageDirectory()
    private val appFiles = java.util.concurrent.ConcurrentHashMap<String, MutableList<Pair<String, Uri>>>()
    private val saf: SafTree? = opt.customTree?.let { t ->
        try { SafTree(context, Uri.parse(t)).takeIf { it.isWritable() } } catch (e: Exception) { null }
    }
    /** Predmemorija provjere postojanja mapa (relativna putanja → stvarni zapis putanje, "" = ne postoji). */
    private val existing = java.util.concurrent.ConcurrentHashMap<String, String>()

    /** Aplikacije primljene dosad (u svim sesijama ovog primanja). */
    fun receivedApps(): List<ReceivedApp> = appFiles.map { (label, files) ->
        // base.apk ide prvi pri instalaciji podijeljenih APK-ova.
        ReceivedApp(label, synchronized(files) { files.sortedBy { if (it.first == "base.apk") 0 else 1 }.map { it.second } })
    }

    private fun rememberApp(item: TransferItem, uri: Uri) {
        appFiles.getOrPut(appLabel(item)) { java.util.Collections.synchronizedList(mutableListOf()) }.add(item.name to uri)
    }

    override fun freeBytes(): Long = try {
        StatFs(root.absolutePath).availableBytes - RESERVE
    } catch (e: Exception) {
        Long.MAX_VALUE
    }

    // ---------- Odredište ----------

    private sealed class Target {
        data class InFile(val dir: File) : Target()
        data class InMedia(val collection: Uri, val relativePath: String) : Target()
        data class InSaf(val relativePath: String) : Target()
    }

    private fun safe(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "_" }

    /** Podmapa unutar zadane/ručne mape, npr. "Fotografije/" ili "Fotografije/Camera/". */
    private fun categorySub(item: TransferItem): String {
        val base = safe(opt.folderName(item.category)) + "/"
        return when {
            item.category == TransferCategory.APPS -> base + item.relativeDir.removePrefix("Apps/")
            opt.keepSubfolders -> base + item.relativeDir.trimEnd('/').substringAfterLast('/').let { if (it.isEmpty()) "" else safe(it) + "/" }
            else -> base
        }
    }

    private fun mime(item: TransferItem): String {
        item.mime?.takeIf { it.contains('/') }?.let { return it }
        val ext = FileClassifier.extension(item.name)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    /** MediaStore zbirka i dopuštene glavne mape za vrstu datoteke. */
    private fun mediaCollection(m: String): Pair<Uri, List<String>> {
        val vol = MediaStore.VOLUME_EXTERNAL_PRIMARY
        return when {
            m.startsWith("image/") -> MediaStore.Images.Media.getContentUri(vol) to listOf("DCIM", "Pictures")
            m.startsWith("video/") -> MediaStore.Video.Media.getContentUri(vol) to listOf("DCIM", "Movies", "Pictures")
            m.startsWith("audio/") -> MediaStore.Audio.Media.getContentUri(vol) to
                listOf("Music", "Alarms", "Notifications", "Podcasts", "Ringtones", "Audiobooks", "Recordings")
            else -> MediaStore.Files.getContentUri(vol) to listOf("Download", "Documents")
        }
    }

    /**
     * Postoji li na ovom mobitelu ista mapa (upit MediaStoreu, bez pristupa svim datotekama); vraća zapis putanje.
     * Vidi samo mape s medijima koje aplikacija smije čitati (zato se pri primanju traže dopuštenja za medije).
     */
    private fun mediaFolder(relDir: String): String? = existing.getOrPut(relDir) {
        val found: String? = try {
            resolver.query(
                MediaStore.Files.getContentUri("external"), arrayOf(MediaStore.MediaColumns.RELATIVE_PATH),
                "${MediaStore.MediaColumns.RELATIVE_PATH} = ?", arrayOf(relDir), null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) {
            null
        }
        found ?: ""
    }.takeIf { it.isNotEmpty() }

    private fun target(item: TransferItem): Target {
        if (opt.sameFolders && item.category != TransferCategory.APPS && item.relativeDir.isNotEmpty() &&
            !StorageAccess.isProtectedDir(item.relativeDir)
        ) {
            if (direct) {
                val dir = File(root, item.relativeDir)
                if (dir.isDirectory) return Target.InFile(dir)
            } else {
                val (collection, roots) = mediaCollection(mime(item))
                val top = item.relativeDir.substringBefore('/')
                if (roots.any { it.equals(top, ignoreCase = true) }) {
                    mediaFolder(item.relativeDir)?.let { return Target.InMedia(collection, it) }
                }
            }
        }
        val sub = categorySub(item)
        return when {
            saf != null -> Target.InSaf(sub)
            direct -> Target.InFile(File(root, BuildConfig.APP_FOLDER + "/" + sub))
            else -> Target.InMedia(MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), "Download/" + BuildConfig.APP_FOLDER + "/" + sub)
        }
    }

    override fun shouldSkip(item: TransferItem): Boolean {
        if (!opt.skipExisting) return false
        return try {
            when (val t = target(item)) {
                is Target.InFile -> File(t.dir, item.name).let { it.exists() && it.length() == item.size }
                is Target.InMedia -> resolver.query(
                    t.collection, arrayOf(MediaStore.MediaColumns._ID),
                    "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.SIZE}=?",
                    arrayOf(t.relativePath, item.name, item.size.toString()), null
                )?.use { it.count > 0 } ?: false
                is Target.InSaf -> saf!!.dir(t.relativePath, create = false)?.let { d -> saf.find(d, item.name)?.second == item.size } ?: false
            }
        } catch (e: Exception) {
            false
        }
    }

    override fun create(item: TransferItem): IncomingFile = when (val t = target(item)) {
        is Target.InFile -> createFile(t.dir, item)
        is Target.InMedia -> createMedia(t.collection, t.relativePath, item)
        is Target.InSaf -> createSaf(t.relativePath, item)
    }

    private fun appLabel(item: TransferItem): String =
        item.relativeDir.removePrefix("Apps/").trimEnd('/').ifEmpty { item.name.removeSuffix(".apk") }

    private fun createFile(dirIn: File, item: TransferItem): IncomingFile {
        val dir = dirIn.apply { mkdirs() }
        var target = File(dir, item.name)
        if (target.exists()) target = uniqueFile(dir, item.name)
        val part = File(dir, "." + target.name + ".photosync-part")
        val out = BufferedOutputStream(FileOutputStream(part), 1 shl 20)
        return object : IncomingFile {
            override val output: OutputStream = out
            override fun commit() {
                out.close()
                if (!part.renameTo(target)) throw IOException("rename")
                // Izvorni datum izmjene datoteke.
                item.modified?.let { target.setLastModified(it) }
                MediaScannerConnection.scanFile(context, arrayOf(target.absolutePath), null, null)
                if (item.category == TransferCategory.APPS) rememberApp(item, Uri.fromFile(target))
            }
            override fun abort() {
                try { out.close() } catch (e: Exception) { }
                part.delete()
            }
        }
    }

    private fun createMedia(collection: Uri, relativePath: String, item: TransferItem): IncomingFile {
        val m = mime(item)
        val isMedia = m.startsWith("image/") || m.startsWith("video/")
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, item.name)
            put(MediaStore.MediaColumns.MIME_TYPE, m)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
            if (isMedia) (item.taken ?: item.modified)?.let { put(MediaStore.MediaColumns.DATE_TAKEN, it) }
        }
        val uri: Uri = resolver.insert(collection, values) ?: throw IOException("insert")
        val raw = try {
            resolver.openOutputStream(uri, "w") ?: throw IOException("open")
        } catch (e: Exception) {
            resolver.delete(uri, null, null); throw e
        }
        val out = BufferedOutputStream(raw, 1 shl 20)
        return object : IncomingFile {
            override val output: OutputStream = out
            override fun commit() {
                out.close()
                if (isMedia && item.taken == null) item.modified?.let { embedDate(uri, item.name, it) }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
                item.modified?.let { restoreModified(uri, it) }
                if (item.category == TransferCategory.APPS) rememberApp(item, uri)
            }
            override fun abort() {
                try { out.close() } catch (e: Exception) { }
                try { resolver.delete(uri, null, null) } catch (e: Exception) { }
            }
        }
    }

    private fun createSaf(relativePath: String, item: TransferItem): IncomingFile {
        val tree = saf!!
        val dir = tree.dir(relativePath, create = true) ?: throw IOException("mkdir")
        val m = mime(item)
        val doc = tree.create(dir, m, item.name)
        val raw = try {
            resolver.openOutputStream(doc, "w") ?: throw IOException("open")
        } catch (e: Exception) {
            tree.delete(doc); throw e
        }
        val out = BufferedOutputStream(raw, 1 shl 20)
        return object : IncomingFile {
            override val output: OutputStream = out
            override fun commit() {
                out.close()
                val isMedia = m.startsWith("image/") || m.startsWith("video/")
                if (isMedia && item.taken == null) item.modified?.let { embedDate(doc, item.name, it) }
                item.modified?.let { millis -> tree.pathOf(doc)?.let { p -> if (File(p).setLastModified(millis)) MediaScannerConnection.scanFile(context, arrayOf(p), null, null) } }
                if (item.category == TransferCategory.APPS) rememberApp(item, doc)
            }
            override fun abort() {
                try { out.close() } catch (e: Exception) { }
                tree.delete(doc)
            }
        }
    }

    /** Upisuje datum u EXIF (JPG/PNG/WEBP) ili MP4/MOV, samo ako datoteka nema vlastiti datum snimanja. */
    private fun embedDate(uri: Uri, name: String, millis: Long) {
        val ext = FileClassifier.extension(name)
        try {
            resolver.openFileDescriptor(uri, "rw")?.use { pfd ->
                when (ext) {
                    in DateWriter.EXIF_EXT -> {
                        val exif = ExifInterface(pfd.fileDescriptor)
                        if (exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL).isNullOrBlank()) {
                            val zdt = java.time.Instant.ofEpochMilli(millis).atZone(java.time.ZoneId.systemDefault())
                            val text = zdt.format(java.time.format.DateTimeFormatter.ofPattern("yyyy:MM:dd HH:mm:ss"))
                            val offset = zdt.offset.id.let { if (it == "Z") "+00:00" else it }
                            exif.setAttribute(ExifInterface.TAG_DATETIME_ORIGINAL, text)
                            exif.setAttribute(ExifInterface.TAG_DATETIME_DIGITIZED, text)
                            exif.setAttribute(ExifInterface.TAG_OFFSET_TIME_ORIGINAL, offset)
                            exif.saveAttributes()
                        }
                    }
                    in DateWriter.MP4_EXT -> {
                        val io = DateWriter.FdIO(pfd.fileDescriptor)
                        val current = Mp4Dates.read(io)
                        if (current == null || current < MIN_VALID_DATE) Mp4Dates.write(io, millis)
                    }
                }
            }
        } catch (e: Throwable) {
            // Datum je dodatak – datoteka je već ispravno primljena.
        }
    }

    /** Pokušaj vraćanja izvornog datuma izmjene za datoteku koju je aplikacija sama stvorila. */
    private fun restoreModified(uri: Uri, millis: Long) {
        try {
            @Suppress("DEPRECATION")
            val path = resolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) c.getString(0) else null
            } ?: return
            val f = File(path)
            if (f.exists() && f.setLastModified(millis)) {
                MediaScannerConnection.scanFile(context, arrayOf(path), null, null)
            }
        } catch (e: Exception) {
        }
    }

    private fun uniqueFile(dir: File, name: String): File {
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "").let { if (it.isEmpty()) "" else ".$it" }
        var i = 1
        while (true) {
            val f = File(dir, "$base ($i)$ext")
            if (!f.exists()) return f
            i++
        }
    }

    companion object {
        /** Sigurnosna rezerva slobodnog prostora (200 MB). */
        private const val RESERVE = 200L * 1024 * 1024
        /** 1. 1. 1990. – stariji datum u MP4 smatra se nepostojećim (npr. 0 = 1904.). */
        private const val MIN_VALID_DATE = 631_152_000_000L

        /** Putanja mape u koju idu primljene datoteke (za prikaz korisniku). */
        fun receiveRootLabel(customTree: String?): String {
            val base = Environment.getExternalStorageDirectory().absolutePath
            if (customTree != null) {
                val name = StorageAccess.treeDisplayName(customTree)
                return if (name.startsWith("[")) name else "$base/${name.trimStart('/')}".trimEnd('/')
            }
            val rel = if (StorageAccess.hasAllFilesAccess()) BuildConfig.APP_FOLDER else "Download/" + BuildConfig.APP_FOLDER
            return "$base/$rel"
        }
    }
}

/** Pisanje u mapu koju je korisnik odabrao sistemskim biračem (Storage Access Framework). */
private class SafTree(context: Context, private val tree: Uri) {
    private val resolver = context.contentResolver
    private val rootDoc: Uri = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
    private val cache = HashMap<String, Uri>()
    private val lock = Any()

    fun isWritable(): Boolean = resolver.persistedUriPermissions.any { it.uri == tree && it.isWritePermission }

    /** Mapa po relativnoj putanji (npr. "Fotografije/Camera/"); stvara je ako [create]. */
    fun dir(relativePath: String, create: Boolean): Uri? = synchronized(lock) {
        var current = rootDoc
        var path = ""
        for (part in relativePath.split('/').filter { it.isNotEmpty() }) {
            path += "$part/"
            val cached = cache[path]
            current = if (cached != null) cached else {
                val existingDir: Uri? = findDir(current, part)
                val created: Uri? = if (existingDir == null && create) {
                    DocumentsContract.createDocument(resolver, current, DocumentsContract.Document.MIME_TYPE_DIR, part)
                } else null
                val found: Uri = existingDir ?: created ?: return@synchronized null
                cache[path] = found
                found
            }
        }
        current
    }

    private fun children(parent: Uri): List<Triple<Uri, String, Pair<String?, Long>>> {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getDocumentId(parent))
        val out = mutableListOf<Triple<Uri, String, Pair<String?, Long>>>()
        resolver.query(
            uri, arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE
            ), null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                out += Triple(DocumentsContract.buildDocumentUriUsingTree(tree, id), name, (if (c.isNull(2)) null else c.getString(2)) to (if (c.isNull(3)) 0L else c.getLong(3)))
            }
        }
        return out
    }

    private fun findDir(parent: Uri, name: String): Uri? =
        children(parent).firstOrNull { it.second.equals(name, true) && it.third.first == DocumentsContract.Document.MIME_TYPE_DIR }?.first

    /** Datoteka istog naziva u mapi: (URI, veličina) ili null. */
    fun find(dir: Uri, name: String): Pair<Uri, Long>? =
        children(dir).firstOrNull { it.second == name && it.third.first != DocumentsContract.Document.MIME_TYPE_DIR }?.let { it.first to it.third.second }

    fun create(dir: Uri, mime: String, name: String): Uri =
        DocumentsContract.createDocument(resolver, dir, mime, name) ?: throw IOException("create")

    fun delete(doc: Uri) {
        try { DocumentsContract.deleteDocument(resolver, doc) } catch (e: Exception) { }
    }

    /** Stvarna putanja (samo interna memorija i uz pristup svim datotekama) – za vraćanje datuma izmjene. */
    fun pathOf(doc: Uri): String? {
        if (!StorageAccess.hasAllFilesAccess()) return null
        val id = try { DocumentsContract.getDocumentId(doc) } catch (e: Exception) { return null }
        if (!id.startsWith("primary:")) return null
        return Environment.getExternalStorageDirectory().absolutePath + "/" + id.removePrefix("primary:")
    }
}
