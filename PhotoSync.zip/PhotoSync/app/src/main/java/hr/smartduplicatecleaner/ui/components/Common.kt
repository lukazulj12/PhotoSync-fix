package hr.smartduplicatecleaner.ui.components

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.model.SourceType
import hr.smartduplicatecleaner.ui.theme.LocalStatusColors
import java.io.File

/** Status datoteke u pregledu. */
enum class FileStatus { KEEP, DELETE_SUGGESTED, DELETE_MANUAL, PENDING }

fun categoryIcon(c: FileCategory): ImageVector = when (c) {
    FileCategory.IMAGE -> Icons.Filled.Image
    FileCategory.VIDEO -> Icons.Filled.Movie
    FileCategory.AUDIO -> Icons.Filled.AudioFile
    FileCategory.DOCUMENT -> Icons.Filled.Description
    FileCategory.ARCHIVE -> Icons.Filled.Archive
    FileCategory.OTHER -> Icons.Filled.InsertDriveFile
}

/** Model za Coil – datoteke iz datotečnog sustava učitavaju se kao File, ostale preko URI-ja. */
fun imageModel(file: ScannedFile): Any =
    if (file.source == SourceType.FILE_SYSTEM && file.absolutePath != null) File(file.absolutePath!!) else Uri.parse(file.uri)

/**
 * Minijatura: Coil učitava umanjenu sliku veličine prikaza ([sizePx]), nikad punu rezoluciju.
 * Za audio, dokumente i arhive prikazuje se ikona kategorije.
 */
@Composable
fun FileThumbnail(file: ScannedFile, modifier: Modifier = Modifier, sizePx: Int = 360) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        if (file.category == FileCategory.IMAGE || file.category == FileCategory.VIDEO) {
            SubcomposeAsyncImage(
                model = ImageRequest.Builder(LocalContext.current).data(imageModel(file)).size(sizePx).build(),
                contentDescription = file.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                error = { CategoryIcon(file.category) },
                loading = { CategoryIcon(file.category) }
            )
            if (file.category == FileCategory.VIDEO) {
                Icon(
                    Icons.Filled.Movie, null,
                    tint = Color.White,
                    modifier = Modifier.align(Alignment.BottomStart).padding(4.dp).size(18.dp)
                )
            }
        } else {
            CategoryIcon(file.category)
        }
    }
}

@Composable
private fun CategoryIcon(c: FileCategory) {
    Icon(categoryIcon(c), null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
}

/** Oznaka statusa – boja, ikona i tekst. */
@Composable
fun StatusBadge(status: FileStatus, modifier: Modifier = Modifier) {
    val sc = LocalStatusColors.current
    val (bg, fg, icon, text) = when (status) {
        FileStatus.KEEP -> Quad(sc.keep, sc.onKeep, Icons.Filled.CheckCircle, stringResource(R.string.status_keep))
        FileStatus.DELETE_SUGGESTED -> Quad(sc.delete, sc.onDelete, Icons.Filled.Delete, stringResource(R.string.status_delete_suggested))
        FileStatus.DELETE_MANUAL -> Quad(sc.delete, sc.onDelete, Icons.Filled.Delete, stringResource(R.string.status_delete_manual))
        FileStatus.PENDING -> Quad(sc.pending, Color.White, Icons.Filled.HelpOutline, stringResource(R.string.status_pending))
    }
    Surface(color = bg, contentColor = fg, shape = RoundedCornerShape(6.dp), modifier = modifier) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, modifier = Modifier.size(16.dp))
            Text(
                text, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 4.dp), maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

private data class Quad(val a: Color, val b: Color, val c: ImageVector, val d: String)

/** Rub kartice prema statusu – datoteka za čuvanje i za brisanje razlikuju se i obrubom. */
@Composable
fun Modifier.statusBorder(status: FileStatus, width: Dp = 3.dp): Modifier {
    val sc = LocalStatusColors.current
    val color = when (status) {
        FileStatus.KEEP -> sc.keep
        FileStatus.DELETE_SUGGESTED, FileStatus.DELETE_MANUAL -> sc.delete
        FileStatus.PENDING -> sc.pending
    }
    return this.border(width, color, RoundedCornerShape(14.dp))
}

/** Redak "oznaka: vrijednost" u detaljima datoteke. */
@Composable
fun InfoLine(label: String, value: String, emphasize: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
        Text(
            "$label: ", style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            value, style = MaterialTheme.typography.bodySmall,
            fontWeight = if (emphasize) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

/** Kartica s upozorenjem ili obavijesti. */
@Composable
fun NoticeCard(text: String, modifier: Modifier = Modifier, warning: Boolean = true) {
    val sc = LocalStatusColors.current
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (warning) sc.pendingContainer else MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(
                if (warning) Icons.Filled.Warning else Icons.Filled.CheckCircle, null,
                tint = if (warning) sc.pending else MaterialTheme.colorScheme.onSecondaryContainer
            )
            Text(text, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = modifier.padding(top = 16.dp, bottom = 6.dp)
    )
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.padding(4.dp)) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
