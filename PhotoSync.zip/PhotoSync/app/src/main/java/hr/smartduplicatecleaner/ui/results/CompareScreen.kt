package hr.smartduplicatecleaner.ui.results

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.ui.components.DisplayPrefs
import hr.smartduplicatecleaner.ui.components.FileStatus
import hr.smartduplicatecleaner.ui.components.FileThumbnail
import hr.smartduplicatecleaner.ui.components.StatusBadge
import hr.smartduplicatecleaner.ui.components.formatDateTime
import hr.smartduplicatecleaner.ui.components.formatSize
import hr.smartduplicatecleaner.ui.components.imageModel
import hr.smartduplicatecleaner.ui.theme.LocalStatusColors

/**
 * Usporedba preko cijelog zaslona: listanje datoteka u grupi, povećanje (dva prsta ili dvostruki dodir)
 * i način "usporedno" s dvije fotografije jedna iznad druge.
 */
@Composable
fun CompareScreen(vm: ReviewViewModel, groupId: String, startIndex: Int, prefs: DisplayPrefs, onBack: () -> Unit) {
    val state by vm.state.collectAsState()
    val group = state.groups.firstOrNull { it.id == groupId }
    val files = group?.fileKeys?.mapNotNull { state.files[it] }.orEmpty()
    if (group == null || files.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(stringResource(R.string.group_not_found)) }
        return
    }
    val pager = rememberPagerState(initialPage = startIndex.coerceIn(0, files.size - 1)) { files.size }
    var split by rememberSaveable { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().statusBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back), tint = Color.White) }
            Text(
                "${pager.currentPage + 1} / ${files.size}",
                color = Color.White, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f)
            )
            if (files.size >= 2) {
                IconButton(onClick = { split = !split }) {
                    Icon(Icons.Filled.ViewAgenda, stringResource(R.string.side_by_side), tint = if (split) MaterialTheme.colorScheme.primary else Color.White)
                }
            }
        }
        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
            val current = files[page]
            if (split) {
                // Trenutačna datoteka gore, sljedeća (kružno) dolje.
                val other = files[(page + 1) % files.size]
                Column(Modifier.fillMaxSize()) {
                    ComparePane(current, state.status(groupId, current.key), prefs, Modifier.weight(1f), vm, groupId)
                    ComparePane(other, state.status(groupId, other.key), prefs, Modifier.weight(1f), vm, groupId)
                }
            } else {
                ComparePane(current, state.status(groupId, current.key), prefs, Modifier.fillMaxSize(), vm, groupId)
            }
        }
    }
}

@Composable
private fun ComparePane(
    file: ScannedFile,
    status: FileStatus,
    prefs: DisplayPrefs,
    modifier: Modifier,
    vm: ReviewViewModel,
    groupId: String
) {
    val sc = LocalStatusColors.current
    Box(modifier.clipToBounds()) {
        if (file.category == FileCategory.IMAGE || file.category == FileCategory.VIDEO) {
            ZoomableImage(file, Modifier.fillMaxSize())
        } else {
            FileThumbnail(file, Modifier.fillMaxSize())
        }
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.65f))
                .navigationBarsPadding()
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            StatusBadge(status)
            Text(file.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
            val details = buildList {
                file.dateTakenMillis?.let { add(formatDateTime(it, prefs)) }
                add(formatSize(file.sizeBytes, prefs))
                if (file.width != null && file.height != null) add("${file.width} × ${file.height}")
            }.joinToString("  ·  ")
            Text(details, color = Color.White, style = MaterialTheme.typography.bodySmall)
            Text(file.relativeDir, color = Color.LightGray, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = { vm.keepOnly(groupId, file.key) },
                    colors = ButtonDefaults.buttonColors(containerColor = sc.keep, contentColor = sc.onKeep)
                ) { Text(stringResource(R.string.keep_this_file)) }
                Checkbox(
                    checked = status == FileStatus.DELETE_SUGGESTED || status == FileStatus.DELETE_MANUAL,
                    onCheckedChange = { vm.toggle(file.key) },
                    colors = CheckboxDefaults.colors(uncheckedColor = Color.White)
                )
                Text(stringResource(R.string.mark_for_deletion), color = Color.White, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

/** Slika s povećanjem: dva prsta za povećanje i pomicanje, dvostruki dodir za brzo povećanje. */
@Composable
private fun ZoomableImage(file: ScannedFile, modifier: Modifier) {
    var scale by remember(file.key) { mutableFloatStateOf(1f) }
    var offset by remember(file.key) { mutableStateOf(Offset.Zero) }
    AsyncImage(
        // Ograničenje na 2048 px: dovoljno oštro za povećanje, bez učitavanja pune rezolucije.
        model = ImageRequest.Builder(LocalContext.current).data(imageModel(file)).size(2048).build(),
        contentDescription = file.name,
        contentScale = ContentScale.Fit,
        modifier = modifier
            .pointerInput(file.key) {
                detectTapGestures(onDoubleTap = {
                    if (scale > 1f) { scale = 1f; offset = Offset.Zero } else scale = 2.5f
                })
            }
            .pointerInput(file.key) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        // Jedan prst bez povećanja prepušta se listanju (pager).
                        if (event.changes.size > 1 || scale > 1f) {
                            scale = (scale * event.calculateZoom()).coerceIn(1f, 6f)
                            offset = if (scale > 1f) offset + event.calculatePan() else Offset.Zero
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
            .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y)
    )
}
