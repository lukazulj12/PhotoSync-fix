package hr.smartduplicatecleaner.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import hr.smartduplicatecleaner.core.format.SizeUnit
import hr.smartduplicatecleaner.core.model.CriterionType
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.FolderPriority
import hr.smartduplicatecleaner.core.model.KeepRules
import hr.smartduplicatecleaner.core.model.ScanSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/** Način brisanja. */
enum class DeletionMode {
    /** Premjesti u koš (MediaStore) ili mapu za oporavak – može se vratiti. */
    RECOVERABLE,
    /** Trajno brisanje. */
    PERMANENT
}

/** Opseg skeniranja. */
enum class ScanScope { WHOLE_STORAGE, SELECTED_FOLDERS }

/** Sve korisničke postavke aplikacije. */
data class AppSettings(
    val scan: ScanSettings = ScanSettings(),
    val rules: KeepRules = KeepRules(),
    val scope: ScanScope = ScanScope.WHOLE_STORAGE,
    /** Odabrane medijske mape (relativne putanje, npr. "DCIM/"), koriste se uz SELECTED_FOLDERS. */
    val selectedMediaDirs: Set<String> = emptySet(),
    /** URI-jevi mapa odobrenih preko Storage Access Frameworka. */
    val safTrees: Set<String> = emptySet(),
    /** Koristi li se "Pristup svim datotekama" kada je odobren. */
    val useAllFilesAccess: Boolean = true,
    val deletionMode: DeletionMode = DeletionMode.RECOVERABLE,
    val europeanDates: Boolean = true,
    val sizeUnit: SizeUnit = SizeUnit.AUTO,
    /** Vremenski interval se primjenjuje samo na dokumente (inače na sve vrste datoteka). */
    val dateFilterDocumentsOnly: Boolean = true,
    /** false = "Sva vremena": vremenski interval se ne primjenjuje (datumi ostaju sačuvani). */
    val dateFilterEnabled: Boolean = false,
    /** Skeniranje u pozadini (usluga s obaviješću) – ne prekida se pri gašenju zaslona ili promjeni aplikacije. */
    val backgroundScan: Boolean = true,
    /** Zaslon ostaje upaljen dok traje skeniranje (dok je aplikacija otvorena). */
    val keepScreenOn: Boolean = false
) {
    /** Postavke skeniranja s primijenjenim opsegom mapa i vremenskim intervalom. */
    fun effectiveScanSettings(): ScanSettings {
        val withDirs = when {
            scope == ScanScope.WHOLE_STORAGE -> scan.copy(includedRelativeDirs = emptySet())
            // Odabrane mape bez ijedne medijske mape: skeniraju se samo SAF mape (oznaka koja ne odgovara nijednoj putanji).
            selectedMediaDirs.isEmpty() -> scan.copy(includedRelativeDirs = setOf(NO_MEDIA_DIRS))
            else -> scan.copy(includedRelativeDirs = selectedMediaDirs)
        }
        return withDirs.copy(
            dateFrom = if (dateFilterEnabled) scan.dateFrom else null,
            dateTo = if (dateFilterEnabled) scan.dateTo else null,
            dateFilterCategories = if (dateFilterDocumentsOnly) setOf(FileCategory.DOCUMENT) else FileCategory.entries.toSet()
        )
    }

    companion object {
        private const val NO_MEDIA_DIRS = "\u0000none"
    }
}

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

/** Spremanje postavki u DataStore – ostaju sačuvane nakon zatvaranja i ponovnog pokretanja. */
class SettingsRepository(private val context: Context) {

    private object K {
        val MAX_SIZE = longPreferencesKey("max_size_bytes") // -1 = bez ograničenja
        val CATEGORIES = stringSetPreferencesKey("categories")
        val FIND_SIMILAR = booleanPreferencesKey("find_similar")
        val SIMILARITY = intPreferencesKey("similarity_percent")
        val ORDER = stringPreferencesKey("criteria_order")
        val DATE_PREF = stringPreferencesKey("date_pref")
        val DATE_KIND = stringPreferencesKey("date_kind")
        val SIZE_PREF = stringPreferencesKey("size_pref")
        val PREFER_RES = booleanPreferencesKey("prefer_resolution")
        val USE_FOLDERS = booleanPreferencesKey("use_folder_priority")
        val PREFERRED_FOLDERS = stringPreferencesKey("preferred_folders") // odvojeno novim retkom, redom
        val DEMOTED_FOLDERS = stringPreferencesKey("demoted_folders")
        val DATE_FROM = longPreferencesKey("date_from") // -1 = bez granice
        val DATE_TO = longPreferencesKey("date_to")
        val DATE_DOCS_ONLY = booleanPreferencesKey("date_docs_only")
        val DATE_ENABLED = booleanPreferencesKey("date_filter_enabled")
        val BACKGROUND = booleanPreferencesKey("background_scan")
        val KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
        val SCOPE = stringPreferencesKey("scope")
        val MEDIA_DIRS = stringSetPreferencesKey("media_dirs")
        val SAF_TREES = stringSetPreferencesKey("saf_trees")
        val USE_ALL_FILES = booleanPreferencesKey("use_all_files")
        val DELETION_MODE = stringPreferencesKey("deletion_mode")
        val EURO_DATES = booleanPreferencesKey("euro_dates")
        val SIZE_UNIT = stringPreferencesKey("size_unit")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p -> read(p) }

    suspend fun current(): AppSettings = settings.first()

    private inline fun <reified E : Enum<E>> enumOf(value: String?, default: E): E =
        value?.let { v -> enumValues<E>().firstOrNull { it.name == v } } ?: default

    private fun read(p: Preferences): AppSettings {
        val d = AppSettings()
        val maxSize = p[K.MAX_SIZE]
        val categories = p[K.CATEGORIES]?.mapNotNull { n -> FileCategory.entries.firstOrNull { it.name == n } }?.toSet()
        val order = p[K.ORDER]?.split(',')?.mapNotNull { n -> CriterionType.entries.firstOrNull { it.name == n } }
        return AppSettings(
            scan = d.scan.copy(
                maxFileSizeBytes = when {
                    maxSize == null -> d.scan.maxFileSizeBytes
                    maxSize < 0 -> null
                    else -> maxSize
                },
                categories = categories ?: d.scan.categories,
                findSimilarPhotos = p[K.FIND_SIMILAR] ?: d.scan.findSimilarPhotos,
                similarityPercent = p[K.SIMILARITY] ?: d.scan.similarityPercent,
                dateFrom = p[K.DATE_FROM]?.takeIf { it >= 0 },
                dateTo = p[K.DATE_TO]?.takeIf { it >= 0 }
            ),
            rules = KeepRules(
                order = order?.takeIf { it.isNotEmpty() } ?: d.rules.order,
                datePreference = enumOf(p[K.DATE_PREF], d.rules.datePreference),
                dateKind = enumOf(p[K.DATE_KIND], d.rules.dateKind),
                sizePreference = enumOf(p[K.SIZE_PREF], d.rules.sizePreference),
                preferHigherResolution = p[K.PREFER_RES] ?: d.rules.preferHigherResolution,
                useFolderPriority = p[K.USE_FOLDERS] ?: d.rules.useFolderPriority,
                preferredFolders = folders(p[K.PREFERRED_FOLDERS]) ?: d.rules.preferredFolders,
                demotedFolders = folders(p[K.DEMOTED_FOLDERS]) ?: d.rules.demotedFolders
            ),
            scope = enumOf(p[K.SCOPE], d.scope),
            selectedMediaDirs = p[K.MEDIA_DIRS] ?: d.selectedMediaDirs,
            safTrees = p[K.SAF_TREES] ?: d.safTrees,
            useAllFilesAccess = p[K.USE_ALL_FILES] ?: d.useAllFilesAccess,
            deletionMode = enumOf(p[K.DELETION_MODE], d.deletionMode),
            europeanDates = p[K.EURO_DATES] ?: d.europeanDates,
            sizeUnit = enumOf(p[K.SIZE_UNIT], d.sizeUnit),
            dateFilterDocumentsOnly = p[K.DATE_DOCS_ONLY] ?: d.dateFilterDocumentsOnly,
            dateFilterEnabled = p[K.DATE_ENABLED] ?: d.dateFilterEnabled,
            backgroundScan = p[K.BACKGROUND] ?: d.backgroundScan,
            keepScreenOn = p[K.KEEP_SCREEN_ON] ?: d.keepScreenOn
        )
    }

    private fun folders(text: String?): List<String>? =
        text?.split('\n')?.map { it.trim() }?.filter { it.isNotEmpty() }?.take(FolderPriority.MAX)

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { p ->
            val s = transform(read(p))
            p[K.MAX_SIZE] = s.scan.maxFileSizeBytes ?: -1L
            p[K.CATEGORIES] = s.scan.categories.map { it.name }.toSet()
            p[K.FIND_SIMILAR] = s.scan.findSimilarPhotos
            p[K.SIMILARITY] = s.scan.similarityPercent.coerceIn(70, 98)
            p[K.ORDER] = s.rules.normalizedOrder().joinToString(",") { it.name }
            p[K.DATE_PREF] = s.rules.datePreference.name
            p[K.DATE_KIND] = s.rules.dateKind.name
            p[K.SIZE_PREF] = s.rules.sizePreference.name
            p[K.PREFER_RES] = s.rules.preferHigherResolution
            p[K.USE_FOLDERS] = s.rules.useFolderPriority
            p[K.PREFERRED_FOLDERS] = s.rules.preferredFolders.take(FolderPriority.MAX).joinToString("\n")
            p[K.DEMOTED_FOLDERS] = s.rules.demotedFolders.take(FolderPriority.MAX).joinToString("\n")
            p[K.DATE_FROM] = s.scan.dateFrom ?: -1L
            p[K.DATE_TO] = s.scan.dateTo ?: -1L
            p[K.DATE_DOCS_ONLY] = s.dateFilterDocumentsOnly
            p[K.DATE_ENABLED] = s.dateFilterEnabled
            p[K.BACKGROUND] = s.backgroundScan
            p[K.KEEP_SCREEN_ON] = s.keepScreenOn
            p[K.SCOPE] = s.scope.name
            p[K.MEDIA_DIRS] = s.selectedMediaDirs
            p[K.SAF_TREES] = s.safTrees
            p[K.USE_ALL_FILES] = s.useAllFilesAccess
            p[K.DELETION_MODE] = s.deletionMode.name
            p[K.EURO_DATES] = s.europeanDates
            p[K.SIZE_UNIT] = s.sizeUnit.name
        }
    }

    /** Vraćanje zadanih postavki. Odobrene SAF mape se zadržavaju jer je dopuštenje i dalje dano. */
    suspend fun resetToDefaults() {
        val trees = current().safTrees
        context.dataStore.edit { it.clear() }
        update { AppSettings(safTrees = trees) }
    }

    companion object {
        val SIZE_PRESETS_MB: List<Long> = listOf(1, 5, 10, 25, 50, 100, 250, 500, 1000)
    }
}
