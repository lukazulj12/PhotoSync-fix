package hr.smartduplicatecleaner.ui.transfer

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import hr.smartduplicatecleaner.BuildConfig
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.core.transfer.PairingCode
import hr.smartduplicatecleaner.core.transfer.TransferCategory
import hr.smartduplicatecleaner.core.transfer.TransferItem
import hr.smartduplicatecleaner.data.settings.TransferPrefs
import hr.smartduplicatecleaner.storage.StorageAccess
import hr.smartduplicatecleaner.transfer.AndroidTransferSink
import hr.smartduplicatecleaner.transfer.ApkInstaller
import hr.smartduplicatecleaner.transfer.LocalNet
import hr.smartduplicatecleaner.transfer.TransferFailure
import hr.smartduplicatecleaner.transfer.TransferRole
import hr.smartduplicatecleaner.transfer.TransferState
import hr.smartduplicatecleaner.ui.components.DisplayPrefs
import hr.smartduplicatecleaner.ui.components.DonateButton
import hr.smartduplicatecleaner.ui.components.IntervalPicker
import hr.smartduplicatecleaner.ui.components.NoticeCard
import hr.smartduplicatecleaner.ui.components.RadioLine
import hr.smartduplicatecleaner.ui.components.SectionTitle
import hr.smartduplicatecleaner.ui.components.formatSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun categoryName(c: TransferCategory): String = stringResource(
    when (c) {
        TransferCategory.PHOTOS -> R.string.tr_cat_photos
        TransferCategory.VIDEOS -> R.string.tr_cat_videos
        TransferCategory.AUDIO -> R.string.tr_cat_audio
        TransferCategory.DOCUMENTS -> R.string.tr_cat_documents
        TransferCategory.ARCHIVES -> R.string.tr_cat_archives
        TransferCategory.APK_FILES -> R.string.tr_cat_apk
        TransferCategory.APPS -> R.string.tr_cat_apps
        TransferCategory.OTHER -> R.string.tr_cat_other
    }
)

private fun missing(context: Context, perms: Array<String>) =
    perms.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }.toTypedArray()

/** Stanje lokalne mreže, osvježava se svake 2 sekunde (korisnik u međuvremenu pali žarišnu točku / Wi-Fi). */
@Composable
private fun rememberNetStatus(): LocalNet.Status {
    val context = LocalContext.current
    var status by remember { mutableStateOf(LocalNet.Status(false, false, emptyList())) }
    LaunchedEffect(Unit) {
        while (true) {
            status = withContext(Dispatchers.IO) { LocalNet.status(context) }
            delay(2000)
        }
    }
    return status
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransferScreen(vm: TransferViewModel, prefs: DisplayPrefs) {
    val context = LocalContext.current
    val state by vm.state.collectAsState()
    val send by vm.send.collectAsState()
    val p by vm.prefs.collectAsState()
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        pending?.invoke(); pending = null
    }

    /** Traži dopuštenja (mediji, obavijesti) pa pokreće radnju bez obzira na ishod –
     *  ako nešto nedostaje, prijenos i dalje radi (npr. bez provjere postojećih datoteka). */
    fun withPermissions(media: Boolean, action: () -> Unit) {
        val all = mutableListOf<String>()
        if (media && !StorageAccess.hasAllFilesAccess()) all += StorageAccess.mediaPermissions()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) all += Manifest.permission.POST_NOTIFICATIONS
        val need = missing(context, all.toTypedArray())
        if (need.isEmpty()) action() else { pending = action; launcher.launch(need) }
    }

    BackHandler(enabled = send.setup && state is TransferState.Idle) { vm.closeSendSetup() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(if (send.setup && state is TransferState.Idle) R.string.transfer_send_title else R.string.transfer_title)) },
                navigationIcon = {
                    if (send.setup && state is TransferState.Idle) {
                        IconButton(onClick = { vm.closeSendSetup() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) }
                    }
                }
            )
        },
        bottomBar = {
            if (send.setup && state is TransferState.Idle && send.items != null) {
                Surface(tonalElevation = 3.dp) {
                    Button(
                        onClick = { withPermissions(media = false) { vm.startSending() } },
                        enabled = send.selected.isNotEmpty() && PairingCode.normalize(send.code) != null &&
                            (send.host.isBlank() || LocalNet.isIpv4(send.host)),
                        modifier = Modifier.fillMaxWidth().padding(16.dp).height(56.dp)
                    ) {
                        Icon(Icons.Filled.Send, null)
                        Spacer(Modifier.size(8.dp))
                        Text(stringResource(R.string.transfer_send_now, send.selected.size, formatSize(send.selectedBytes, prefs)))
                    }
                }
            }
        }
    ) { padding ->
        val modifier = Modifier.fillMaxSize().padding(padding)
        when {
            state !is TransferState.Idle -> StatusContent(state, vm, send, p, prefs, modifier) { action -> withPermissions(false, action) }
            send.setup -> SendSetup(vm, send, p, prefs, modifier) { withPermissions(media = true) { vm.scan() } }
            else -> TransferHome(vm, p, modifier,
                onReceive = { withPermissions(media = p.skipExisting || p.sameFolders) { vm.startReceiving() } },
                onSend = { vm.openSendSetup() })
        }
    }
}

// ---------- Početni zaslon ----------

@Composable
private fun TransferHome(
    vm: TransferViewModel,
    p: TransferPrefs,
    modifier: Modifier,
    onReceive: () -> Unit,
    onSend: () -> Unit
) {
    val net = rememberNetStatus()
    LazyColumn(modifier, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { ConnectionGuide() }
        item { NetStatusCard(net) }
        item {
            BigAction(Icons.Filled.Download, stringResource(R.string.transfer_receive), stringResource(R.string.transfer_receive_hint), onReceive)
        }
        item {
            BigAction(Icons.Filled.Upload, stringResource(R.string.transfer_send), stringResource(R.string.transfer_send_hint), onSend)
        }
        item {
            SectionTitle(stringResource(R.string.section_background))
            Toggle(stringResource(R.string.transfer_background), p.background) { on -> vm.update { it.copy(background = on) } }
            Toggle(stringResource(R.string.keep_screen_on_transfer), p.keepScreenOn) { on -> vm.update { it.copy(keepScreenOn = on) } }
            Text(stringResource(R.string.transfer_background_hint), style = MaterialTheme.typography.bodySmall)
        }
        item { ReceiveOptions(vm, p) }
    }
}

/** Upute za spajanje: žarišna točka na jednom (svejedno kojem) mobitelu, drugi se spaja na nju. */
@Composable
private fun ConnectionGuide() {
    val context = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.tr_guide_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            GuideStep("1", stringResource(R.string.tr_guide_step1))
            OutlinedButton(onClick = { LocalNet.openHotspotSettings(context) }, modifier = Modifier.padding(start = 32.dp)) {
                Icon(Icons.Filled.WifiTethering, null); Spacer(Modifier.size(8.dp)); Text(stringResource(R.string.tr_open_hotspot))
            }
            GuideStep("2", stringResource(R.string.tr_guide_step2))
            OutlinedButton(onClick = { LocalNet.openWifiSettings(context) }, modifier = Modifier.padding(start = 32.dp)) {
                Icon(Icons.Filled.Wifi, null); Spacer(Modifier.size(8.dp)); Text(stringResource(R.string.tr_open_wifi))
            }
            GuideStep("3", stringResource(R.string.tr_guide_step3))
            Text(stringResource(R.string.tr_guide_same_wifi), style = MaterialTheme.typography.bodySmall)
            Text(stringResource(R.string.tr_guide_tips), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun GuideStep(number: String, text: String) {
    Row(verticalAlignment = Alignment.Top) {
        Surface(shape = MaterialTheme.shapes.small, color = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp)) {
            Text(number, color = MaterialTheme.colorScheme.onPrimary, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 2.dp))
        }
        Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(start = 8.dp))
    }
}

/** Stanje mreže ovog mobitela (žarišna točka / Wi-Fi / nije spojen). */
@Composable
private fun NetStatusCard(net: LocalNet.Status) {
    val ok = net.ready
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (ok) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (ok) Icons.Filled.CheckCircle else Icons.Filled.Warning, null)
            Column(Modifier.padding(start = 12.dp)) {
                val text = when {
                    net.hotspotOn && net.wifiConnected -> stringResource(R.string.tr_net_both)
                    net.hotspotOn -> stringResource(R.string.tr_net_hotspot)
                    net.wifiConnected -> stringResource(R.string.tr_net_wifi)
                    else -> stringResource(R.string.tr_net_none)
                }
                Text(text, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                if (ok) Text(stringResource(R.string.tr_net_ip, net.addresses.joinToString(", ")), style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun BigAction(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, hint: String, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
            Column(Modifier.padding(start = 16.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text(hint, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }
    }
}

@Composable
private fun Toggle(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Postavke primanja: preskakanje postojećih, iste mape, zadana ili ručno odabrana mapa. */
@Composable
private fun ReceiveOptions(vm: TransferViewModel, p: TransferPrefs) {
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
                vm.update { it.copy(customTree = uri.toString()) }
            } catch (e: SecurityException) {
                // Mapa ne dopušta trajni pristup – ostaje zadana.
            }
        }
    }
    Column {
        SectionTitle(stringResource(R.string.transfer_receiving_options))
        Toggle(stringResource(R.string.transfer_skip_existing), p.skipExisting) { on -> vm.update { it.copy(skipExisting = on) } }
        Toggle(stringResource(R.string.tr_same_folders), p.sameFolders) { on -> vm.update { it.copy(sameFolders = on) } }
        Text(stringResource(R.string.tr_same_folders_hint), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(if (p.sameFolders) R.string.tr_dest_other_title else R.string.tr_dest_title),
            style = MaterialTheme.typography.labelLarge
        )
        RadioLine(p.customTree == null, stringResource(R.string.tr_dest_default, AndroidTransferSink.receiveRootLabel(null))) {
            vm.update { it.copy(customTree = null) }
        }
        RadioLine(
            p.customTree != null,
            if (p.customTree != null) stringResource(R.string.tr_dest_custom_set, StorageAccess.treeDisplayName(p.customTree))
            else stringResource(R.string.tr_dest_custom)
        ) { picker.launch(null) }
        if (p.customTree != null) {
            TextButton(onClick = { picker.launch(null) }) { Text(stringResource(R.string.tr_dest_change)) }
        }
        Toggle(stringResource(R.string.transfer_keep_subfolders), p.keepSubfolders) { on -> vm.update { it.copy(keepSubfolders = on) } }
        Text(stringResource(R.string.transfer_dates_hint), style = MaterialTheme.typography.bodySmall)
    }
}

// ---------- Priprema slanja ----------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SendSetup(
    vm: TransferViewModel,
    send: SendUi,
    p: TransferPrefs,
    prefs: DisplayPrefs,
    modifier: Modifier,
    onScan: () -> Unit
) {
    LazyColumn(modifier, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            SectionTitle(stringResource(R.string.transfer_what))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TransferCategory.entries.forEach { c ->
                    FilterChip(
                        selected = c in p.categories,
                        onClick = { vm.update { s -> s.copy(categories = if (c in s.categories) s.categories - c else s.categories + c) } },
                        label = { Text(categoryName(c)) }
                    )
                }
            }
            if (TransferCategory.APPS in p.categories) Text(stringResource(R.string.transfer_apps_hint), style = MaterialTheme.typography.bodySmall)
            if (!StorageAccess.hasAllFilesAccess() && p.categories.any { it in NON_MEDIA }) {
                Text(stringResource(R.string.transfer_documents_hint), style = MaterialTheme.typography.bodySmall)
            }
            SectionTitle(stringResource(R.string.date_range_title))
            IntervalPicker(
                enabled = p.intervalEnabled, from = p.from, to = p.to, prefs = prefs,
                onEnabled = { on -> vm.update { it.copy(intervalEnabled = on) } },
                onChange = { f, t -> vm.update { it.copy(from = f, to = t) } }
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = onScan, enabled = !send.scanning && p.categories.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Search, null); Spacer(Modifier.size(8.dp)); Text(stringResource(R.string.transfer_scan))
            }
            if (send.scanning) Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(24.dp)); Text(stringResource(R.string.phase_listing), Modifier.padding(start = 12.dp))
            }
        }
        val items = send.items
        if (items != null) {
            item {
                SectionTitle(stringResource(R.string.transfer_found, items.size, formatSize(items.sumOf { it.size }, prefs)))
                Text(stringResource(R.string.transfer_folders_hint), style = MaterialTheme.typography.bodySmall)
                Row {
                    TextButton(onClick = { vm.setAllFolders(true) }) { Text(stringResource(R.string.select_all)) }
                    TextButton(onClick = { vm.setAllFolders(false) }) { Text(stringResource(R.string.select_none)) }
                }
            }
            items(send.folders, key = { it.dir }) { f ->
                Row(Modifier.fillMaxWidth().clickable { vm.toggleFolder(f.dir) }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = f.dir !in send.excluded, onCheckedChange = { vm.toggleFolder(f.dir) })
                    Column(Modifier.weight(1f)) {
                        Text(f.dir.ifEmpty { "/" }, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(
                            f.categories.map { categoryName(it) }.joinToString(", "),
                            style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text("${f.count} · ${formatSize(f.bytes, prefs)}", style = MaterialTheme.typography.labelMedium)
                }
            }
            item {
                SectionTitle(stringResource(R.string.transfer_code_title))
                CodeAndAddress(vm, send, showAddressInitially = false)
                Text(stringResource(R.string.transfer_code_hint), style = MaterialTheme.typography.bodySmall)
                NetStatusCard(rememberNetStatus())
            }
        }
    }
}

/** Unos koda (4 znamenke) i, po potrebi, IP adrese novog mobitela. */
@Composable
private fun CodeAndAddress(vm: TransferViewModel, send: SendUi, showAddressInitially: Boolean) {
    var showAddress by rememberSaveable { mutableStateOf(showAddressInitially || send.host.isNotEmpty()) }
    OutlinedTextField(
        value = send.code, onValueChange = { vm.setCode(it) }, singleLine = true,
        label = { Text(stringResource(R.string.transfer_code_label)) },
        placeholder = { Text("1234") },
        textStyle = TextStyle(fontSize = 28.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, letterSpacing = 8.sp),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        modifier = Modifier.fillMaxWidth()
    )
    if (showAddress || showAddressInitially) {
        OutlinedTextField(
            value = send.host, onValueChange = { vm.setHost(it) }, singleLine = true,
            label = { Text(stringResource(R.string.transfer_address_label)) },
            placeholder = { Text("192.168.43.1") },
            supportingText = { Text(stringResource(R.string.tr_address_optional)) },
            isError = send.host.isNotBlank() && !LocalNet.isIpv4(send.host),
            textStyle = TextStyle(fontSize = 20.sp, fontFamily = FontFamily.Monospace),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
    } else {
        TextButton(onClick = { showAddress = true }) { Text(stringResource(R.string.tr_enter_ip)) }
    }
}

private val NON_MEDIA = setOf(TransferCategory.DOCUMENTS, TransferCategory.ARCHIVES, TransferCategory.APK_FILES, TransferCategory.OTHER)

// ---------- Tijek i rezultat ----------

@Composable
private fun StatusContent(
    state: TransferState,
    vm: TransferViewModel,
    send: SendUi,
    p: TransferPrefs,
    prefs: DisplayPrefs,
    modifier: Modifier,
    withPermissions: (() -> Unit) -> Unit
) {
    val context = LocalContext.current
    LazyColumn(modifier, contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        when (state) {
            is TransferState.Preparing -> item {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Text(
                        stringResource(
                            when {
                                state.role == TransferRole.RECEIVE -> R.string.transfer_preparing
                                state.searching -> R.string.tr_searching
                                else -> R.string.transfer_connecting
                            }
                        ),
                        Modifier.padding(16.dp), textAlign = TextAlign.Center
                    )
                    OutlinedButton(onClick = { vm.cancel() }) { Text(stringResource(R.string.cancel)) }
                }
            }
            is TransferState.Waiting -> {
                item { WaitingCard(state.code) }
                item { ReceiveFolderCard(p) }
                item {
                    Text(stringResource(R.string.transfer_waiting_hint), style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = { vm.cancel() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.cancel)) }
                }
            }
            is TransferState.Active -> item {
                val pr = state.progress
                val bps = pr.bytesPerSecond()
                val eta = if (bps > 0) (pr.bytesTotal - pr.bytesDone).coerceAtLeast(0) / bps else -1
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            stringResource(if (state.role == TransferRole.SEND) R.string.transfer_sending else R.string.transfer_receiving),
                            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold
                        )
                        if (state.peer.isNotBlank()) Text(state.peer, style = MaterialTheme.typography.bodySmall)
                        LinearProgressIndicator(
                            progress = { if (pr.bytesTotal > 0) pr.bytesDone.toFloat() / pr.bytesTotal else 0f },
                            modifier = Modifier.fillMaxWidth().height(8.dp)
                        )
                        Text(stringResource(R.string.transfer_files_progress, pr.filesDone, pr.filesTotal))
                        Text(formatSize(pr.bytesDone, prefs) + " / " + formatSize(pr.bytesTotal, prefs))
                        Text(stringResource(R.string.transfer_speed, formatSize(bps, prefs) + "/s"), fontWeight = FontWeight.SemiBold)
                        if (eta >= 0) Text(stringResource(R.string.transfer_eta, formatDuration(eta)))
                        if (pr.failed > 0) Text(stringResource(R.string.report_failed, pr.failed), color = MaterialTheme.colorScheme.error)
                        if (state.role == TransferRole.RECEIVE) ReceiveFolderCard(p)
                        OutlinedButton(onClick = { vm.cancel() }) { Text(stringResource(R.string.cancel)) }
                    }
                }
                Text(stringResource(R.string.transfer_active_hint), style = MaterialTheme.typography.bodySmall)
            }
            is TransferState.Finished -> {
                val r = state.result
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                stringResource(
                                    when {
                                        r.cancelled -> R.string.transfer_cancelled
                                        r.failed.isNotEmpty() -> R.string.tr_done_with_errors
                                        else -> R.string.transfer_done
                                    }
                                ),
                                style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold
                            )
                            Text(stringResource(R.string.transfer_done_files, r.succeeded.size, formatSize(r.bytes, prefs)))
                            val secs = (r.millis / 1000).coerceAtLeast(1)
                            Text(stringResource(R.string.transfer_done_time, formatDuration(secs), formatSize(r.bytes / secs, prefs) + "/s"))
                            if (r.skipped.isNotEmpty()) Text(stringResource(R.string.transfer_done_skipped, r.skipped.size))
                            if (r.failed.isNotEmpty()) {
                                Text(stringResource(R.string.tr_not_transferred, r.failed.size), color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                            }
                            if (state.role == TransferRole.SEND && r.failed.isNotEmpty()) {
                                Button(onClick = { withPermissions { vm.retryFailed() } }, modifier = Modifier.fillMaxWidth()) {
                                    Icon(Icons.Filled.Refresh, null); Spacer(Modifier.size(8.dp))
                                    Text(stringResource(R.string.tr_resend_failed, r.failed.size))
                                }
                                Text(stringResource(R.string.tr_resend_hint), style = MaterialTheme.typography.bodySmall)
                            }
                            if (state.role == TransferRole.RECEIVE && state.listeningCode != null) {
                                Text(
                                    stringResource(R.string.tr_still_receiving, PairingCode.display(state.listeningCode)),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            if (state.role == TransferRole.RECEIVE) ReceiveFolderCard(p)
                            if (BuildConfig.SHOW_DONATE && !r.cancelled && r.succeeded.isNotEmpty()) {
                                Text(stringResource(R.string.donate_after_transfer), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
                                DonateButton(Modifier.fillMaxWidth())
                            }
                            Button(onClick = { vm.done() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.done)) }
                        }
                    }
                }
                if (state.role == TransferRole.RECEIVE && state.apps.isNotEmpty()) {
                    item {
                        SectionTitle(stringResource(R.string.transfer_apps_received, state.apps.size))
                        Text(
                            stringResource(if (ApkInstaller.isAvailable) R.string.transfer_apps_install_hint else R.string.transfer_apps_saved_hint),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (ApkInstaller.isAvailable) items(state.apps, key = { it.label }) { app ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(app.label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            TextButton(onClick = {
                                if (!ApkInstaller.canInstall(context)) context.startActivity(ApkInstaller.permissionIntent(context))
                                else try { ApkInstaller.install(context, app) } catch (e: Exception) { }
                            }) { Text(stringResource(R.string.transfer_install)) }
                        }
                    }
                }
                if (r.failed.isNotEmpty()) {
                    item { SectionTitle(stringResource(R.string.tr_failed_list_title, r.failed.size)) }
                    items(r.failed.take(500), key = { "f" + it.first.id }) { (item, reason) -> FailedRow(item, reason, prefs) }
                    if (r.failed.size > 500) item { Text("… +" + (r.failed.size - 500), style = MaterialTheme.typography.bodySmall) }
                }
            }
            is TransferState.Failed -> item {
                FailureCard(state, vm, send, prefs, withPermissions)
            }
            TransferState.Idle -> Unit
        }
    }
}

/** Primatelj: veliki kod i istaknuta IP adresa (potrebna samo ako se primatelj ne pronađe automatski). */
@Composable
private fun WaitingCard(code: String) {
    val net = rememberNetStatus()
    val clipboard = LocalClipboardManager.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(stringResource(R.string.transfer_your_code), style = MaterialTheme.typography.titleMedium)
            Text(
                PairingCode.display(code),
                fontSize = 64.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, letterSpacing = 12.sp,
                color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(vertical = 8.dp)
            )
            if (net.ready) {
                Card(
                    Modifier.fillMaxWidth().clickable { clipboard.setText(AnnotatedString(net.addresses.first())) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                    border = BorderStroke(2.dp, MaterialTheme.colorScheme.tertiary)
                ) {
                    Column(Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(stringResource(R.string.tr_ip_title), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onTertiaryContainer)
                        Text(
                            net.addresses.first(),
                            fontSize = 30.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                        if (net.addresses.size > 1) {
                            Text(
                                stringResource(R.string.tr_ip_other, net.addresses.drop(1).joinToString(", ")),
                                style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                        Text(
                            stringResource(R.string.tr_ip_hint), style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                    }
                }
            } else {
                Spacer(Modifier.width(4.dp))
                NetStatusCard(net)
                ConnectionButtons()
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ConnectionButtons() {
    val context = LocalContext.current
    FlowRow(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { LocalNet.openHotspotSettings(context) }) { Text(stringResource(R.string.tr_open_hotspot)) }
        OutlinedButton(onClick = { LocalNet.openWifiSettings(context) }) { Text(stringResource(R.string.tr_open_wifi)) }
    }
}

/** Jedna neuspjela stavka s razumljivim razlogom. */
@Composable
private fun FailedRow(item: TransferItem, reason: String, prefs: DisplayPrefs) {
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(item.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            (item.relativeDir.ifEmpty { "/" }) + " · " + formatSize(item.size, prefs) + " · " + failReason(reason),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error,
            maxLines = 2, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun failReason(reason: String): String = when {
    reason == "connection" -> stringResource(R.string.tr_reason_connection)
    reason == "cancelled" -> stringResource(R.string.tr_reason_cancelled)
    reason == "receiver" -> stringResource(R.string.tr_reason_receiver)
    reason == "short" -> stringResource(R.string.tr_reason_changed)
    reason.startsWith("open") || reason.startsWith("read") -> stringResource(R.string.tr_reason_read)
    reason.startsWith("write") || reason.startsWith("create") || reason.startsWith("commit") -> stringResource(R.string.tr_reason_receiver)
    else -> reason
}

@Composable
private fun FailureCard(
    state: TransferState.Failed,
    vm: TransferViewModel,
    send: SendUi,
    prefs: DisplayPrefs,
    withPermissions: (() -> Unit) -> Unit
) {
    val text = when (state.reason) {
        TransferFailure.NO_NETWORK -> stringResource(R.string.tr_err_network)
        TransferFailure.NOT_FOUND -> stringResource(R.string.tr_err_not_found)
        TransferFailure.CONNECT_FAILED -> stringResource(R.string.tr_err_connect)
        TransferFailure.AUTH_FAILED -> stringResource(R.string.tr_err_code)
        TransferFailure.BUSY -> stringResource(R.string.tr_err_busy)
        TransferFailure.NO_SPACE -> stringResource(R.string.tr_err_space, if (state.freeBytes >= 0) formatSize(state.freeBytes, prefs) else "?")
        TransferFailure.PORT_IN_USE -> stringResource(R.string.tr_err_port)
        TransferFailure.TOO_MANY_ATTEMPTS -> stringResource(R.string.tr_err_attempts)
        TransferFailure.BAD_ADDRESS -> stringResource(R.string.tr_err_address)
        TransferFailure.UNKNOWN -> stringResource(R.string.fail_unknown)
    }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        NoticeCard(text)
        if (state.reason == TransferFailure.NO_NETWORK) {
            NetStatusCard(rememberNetStatus())
            ConnectionButtons()
        }
        // Pošiljatelj: ispravak koda / upis IP adrese i novi pokušaj bez ponovnog odabira datoteka.
        val canRetry = state.role == TransferRole.SEND && send.items != null && state.reason in setOf(
            TransferFailure.NO_NETWORK, TransferFailure.NOT_FOUND, TransferFailure.CONNECT_FAILED,
            TransferFailure.AUTH_FAILED, TransferFailure.BUSY, TransferFailure.BAD_ADDRESS, TransferFailure.UNKNOWN
        )
        if (canRetry) {
            CodeAndAddress(
                vm, send,
                showAddressInitially = state.reason in setOf(TransferFailure.NOT_FOUND, TransferFailure.CONNECT_FAILED, TransferFailure.BAD_ADDRESS)
            )
            Button(
                onClick = {
                    vm.dismissFailure()
                    withPermissions { vm.startSending() }
                },
                enabled = PairingCode.normalize(send.code) != null && (send.host.isBlank() || LocalNet.isIpv4(send.host)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Refresh, null); Spacer(Modifier.size(8.dp)); Text(stringResource(R.string.tr_try_again))
            }
            OutlinedButton(onClick = { vm.dismissFailure() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.back)) }
        } else {
            Button(onClick = { vm.done() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.ok)) }
        }
    }
}

private fun formatDuration(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

/** Prikaz mape u koju se spremaju primljene datoteke. */
@Composable
private fun ReceiveFolderCard(p: TransferPrefs) {
    val path = remember(p.customTree) { AndroidTransferSink.receiveRootLabel(p.customTree) }
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
    ) {
        Column(Modifier.padding(12.dp)) {
            if (p.sameFolders) Text(stringResource(R.string.tr_save_same_first), style = MaterialTheme.typography.bodySmall)
            Text(stringResource(if (p.sameFolders) R.string.tr_save_folder_other else R.string.transfer_save_folder), style = MaterialTheme.typography.labelLarge)
            Text(path, style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold)
            Text(stringResource(R.string.transfer_save_folder_hint), style = MaterialTheme.typography.bodySmall)
        }
    }
}
