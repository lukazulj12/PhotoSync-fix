package hr.smartduplicatecleaner.ui.results

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.core.hash.PerceptualHash
import hr.smartduplicatecleaner.core.model.DuplicateGroup
import hr.smartduplicatecleaner.ui.components.DisplayPrefs
import hr.smartduplicatecleaner.ui.components.FileThumbnail
import hr.smartduplicatecleaner.ui.components.StatusBadge
import hr.smartduplicatecleaner.ui.components.categoryLabel
import hr.smartduplicatecleaner.ui.components.formatSize
import hr.smartduplicatecleaner.ui.components.groupTypeLabel
import hr.smartduplicatecleaner.ui.components.statusBorder

@Composable
fun filterLabel(f: ResultFilter): String = stringResource(
    when (f) {
        ResultFilter.ALL -> R.string.filter_all
        ResultFilter.EXACT -> R.string.filter_exact
        ResultFilter.SAME_NAME -> R.string.filter_same_name
        ResultFilter.SIMILAR_PHOTOS -> R.string.filter_similar
        ResultFilter.VIDEO -> R.string.cat_videos
        ResultFilter.AUDIO -> R.string.cat_audio
        ResultFilter.DOCUMENTS -> R.string.cat_documents
        ResultFilter.OTHER -> R.string.filter_other
    }
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultsScreen(
    vm: ReviewViewModel,
    prefs: DisplayPrefs,
    onBack: () -> Unit,
    onOpenGroup: (String) -> Unit,
    onReviewDeletion: () -> Unit
) {
    val state by vm.state.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        vm.messages.collect { snackbar.showSnackbar(context.getString(it)) }
    }
    var menu by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.found_duplicates)) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } },
                actions = {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, stringResource(R.string.more)) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text(stringResource(R.string.mark_confirmed_only)) }, onClick = { menu = false; vm.applySuggestions(true) })
                        DropdownMenuItem(text = { Text(stringResource(R.string.apply_all_suggestions)) }, onClick = { menu = false; vm.applySuggestions(false) })
                        DropdownMenuItem(text = { Text(stringResource(R.string.clear_all_marks)) }, onClick = { menu = false; vm.clearAll() })
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Button(
                    onClick = onReviewDeletion,
                    enabled = state.marked.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp).height(56.dp)
                ) {
                    Icon(Icons.Filled.Delete, null)
                    Spacer(Modifier.size(8.dp))
                    Text(stringResource(R.string.review_before_delete, state.marked.size, formatSize(state.markedBytes, prefs)))
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            val filters = ResultFilter.entries
            ScrollableTabRow(selectedTabIndex = filters.indexOf(state.filter), edgePadding = 8.dp) {
                filters.forEach { f ->
                    Tab(
                        selected = state.filter == f,
                        onClick = { vm.setFilter(f) },
                        text = { Text("${filterLabel(f)} (${state.countFor(f)})") }
                    )
                }
            }
            when {
                state.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                state.visibleGroups.isEmpty() -> Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        stringResource(if (state.groups.isEmpty()) R.string.no_duplicates else R.string.no_groups_in_filter),
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
                else -> LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(state.visibleGroups, key = { it.id }) { g ->
                        GroupCard(g, state, prefs) { onOpenGroup(g.id) }
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupCard(group: DuplicateGroup, state: ReviewState, prefs: DisplayPrefs, onClick: () -> Unit) {
    val files = group.fileKeys.mapNotNull { state.files[it] }
    val markedInGroup = group.fileKeys.count { it in state.marked }
    val markedBytes = group.fileKeys.filter { it in state.marked }.sumOf { state.files[it]?.sizeBytes ?: 0L }
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AssistChip(onClick = onClick, label = { Text(groupTypeLabel(group.type)) })
                Text(categoryLabel(group.category), style = MaterialTheme.typography.labelMedium)
                group.maxDistance?.let {
                    Text(
                        stringResource(R.string.similarity_percent, PerceptualHash.similarityPercent(it)),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                files.take(4).forEach { f ->
                    val status = state.status(group.id, f.key)
                    FileThumbnail(f, Modifier.weight(1f).height(84.dp).statusBorder(status, 2.dp), sizePx = 240)
                }
                repeat(4 - minOf(4, files.size)) { Spacer(Modifier.weight(1f)) }
            }
            Text(
                files.first().name + if (files.size > 1) "  +${files.size - 1}" else "",
                style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.group_summary, files.size, markedInGroup, formatSize(markedBytes, prefs)),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.weight(1f)
                )
                if (markedInGroup == 0 && state.decisions[group.id]?.needsManual == true) {
                    StatusBadge(hr.smartduplicatecleaner.ui.components.FileStatus.PENDING)
                }
            }
        }
    }
}
