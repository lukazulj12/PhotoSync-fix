package hr.smartduplicatecleaner.scan

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.scan.CancelToken
import hr.smartduplicatecleaner.core.scan.FileSource
import hr.smartduplicatecleaner.core.scan.ScanCancelledException
import hr.smartduplicatecleaner.core.scan.ScanEngine
import hr.smartduplicatecleaner.core.scan.ScanProgress
import hr.smartduplicatecleaner.core.scan.ScanStats
import hr.smartduplicatecleaner.data.ResultsRepository
import hr.smartduplicatecleaner.data.RoomHashCache
import hr.smartduplicatecleaner.data.settings.AppSettings
import hr.smartduplicatecleaner.data.settings.SettingsRepository
import hr.smartduplicatecleaner.storage.AndroidContentAccess
import hr.smartduplicatecleaner.storage.FileSystemSource
import hr.smartduplicatecleaner.storage.MediaStoreSource
import hr.smartduplicatecleaner.storage.SafTreeSource
import hr.smartduplicatecleaner.storage.StorageAccess
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.job
import kotlinx.coroutines.launch

/** Stanje skeniranja koje promatraju zaslon i pozadinska usluga. */
sealed class ScanState {
    data object Idle : ScanState()
    data class Running(val progress: ScanProgress?) : ScanState()
    data class Finished(val stats: ScanStats, val warnings: Int, val finishedAt: Long) : ScanState()
    data object Cancelled : ScanState()
    data class Failed(val message: String) : ScanState()
}

/**
 * Upravlja skeniranjem u opsegu aplikacije – nastavlja raditi kad korisnik napusti zaslon,
 * a pozadinska usluga s obaviješću sprječava da sustav ugasi proces.
 */
class ScanManager(
    private val context: Context,
    private val settingsRepository: SettingsRepository,
    private val results: ResultsRepository,
    private val hashCache: RoomHashCache
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val _state = MutableStateFlow<ScanState>(ScanState.Idle)
    val state: StateFlow<ScanState> = _state.asStateFlow()
    private var job: Job? = null

    val isRunning: Boolean get() = job?.isActive == true

    /** Izvori prema postavkama i odobrenim dopuštenjima. */
    fun buildSources(settings: AppSettings): List<FileSource> {
        val categories = settings.scan.categories
        val sources = mutableListOf<FileSource>()
        val media = categories.intersect(setOf(FileCategory.IMAGE, FileCategory.VIDEO, FileCategory.AUDIO))
        if (media.isNotEmpty()) sources += MediaStoreSource(context, media)
        if (settings.useAllFilesAccess && StorageAccess.hasAllFilesAccess()) sources += FileSystemSource(context)
        settings.safTrees.forEach { sources += SafTreeSource(context, it) }
        return sources
    }

    fun start() {
        if (isRunning) return
        _state.value = ScanState.Running(null)
        job = scope.launch(Dispatchers.IO) {
            val coroutineJob = currentCoroutineContext().job
            try {
                val settings = settingsRepository.current()
                // Rad u pozadini: usluga u prvom planu + wake lock, pa se skeniranje ne prekida
                // kad se zaslon ugasi ili korisnik prijeđe u drugu aplikaciju.
                if (settings.backgroundScan) startService()
                val scanSettings = settings.effectiveScanSettings()
                val engine = ScanEngine(buildSources(settings), AndroidContentAccess(context), hashCache)
                val result = engine.run(scanSettings, settings.rules, CancelToken { !coroutineJob.isActive }) { p ->
                    _state.value = ScanState.Running(p)
                }
                val finishedAt = System.currentTimeMillis()
                results.save(result, finishedAt, scanSettings.maxFileSizeBytes)
                _state.value = ScanState.Finished(result.stats, result.warnings.size, finishedAt)
            } catch (e: ScanCancelledException) {
                _state.value = ScanState.Cancelled
            } catch (e: kotlinx.coroutines.CancellationException) {
                _state.value = ScanState.Cancelled
            } catch (e: OutOfMemoryError) {
                _state.value = ScanState.Failed("OutOfMemoryError")
            } catch (e: Exception) {
                _state.value = ScanState.Failed(e.message ?: e.javaClass.simpleName)
            }
        }
    }

    fun cancel() {
        job?.cancel()
    }

    /** Vraća stanje u mirovanje nakon što korisnik pogleda rezultat. */
    fun acknowledge() {
        if (!isRunning) _state.value = ScanState.Idle
    }

    private fun startService() {
        try {
            ContextCompat.startForegroundService(context, Intent(context, ScanService::class.java))
        } catch (e: Exception) {
            // Npr. ograničenja pokretanja usluga – skeniranje se nastavlja bez obavijesti.
        }
    }
}
