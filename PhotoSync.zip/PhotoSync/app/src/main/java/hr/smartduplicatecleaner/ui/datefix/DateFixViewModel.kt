package hr.smartduplicatecleaner.ui.datefix

import android.content.IntentSender
import android.net.Uri
import android.provider.MediaStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import hr.smartduplicatecleaner.AppContainer
import hr.smartduplicatecleaner.core.dates.DateFixItem
import hr.smartduplicatecleaner.core.dates.DateFixPlanner
import hr.smartduplicatecleaner.core.dates.DateFixSettings
import hr.smartduplicatecleaner.core.dates.DateFixStatus
import hr.smartduplicatecleaner.core.dates.NameDateParser
import hr.smartduplicatecleaner.data.settings.DateFixPrefs
import hr.smartduplicatecleaner.datefix.DateFixMedia
import hr.smartduplicatecleaner.datefix.DateWriteResult
import hr.smartduplicatecleaner.datefix.DateWriter
import hr.smartduplicatecleaner.datefix.MediaFolder
import hr.smartduplicatecleaner.storage.StorageAccess
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.ZoneId

data class DateFixUi(
    val folders: List<MediaFolder>? = null,
    val analyzing: Boolean = false,
    val analyzed: Boolean = false,
    /** Datoteke čiji datum ne odgovara nazivu. */
    val toFix: List<DateFixItem> = emptyList(),
    val okCount: Int = 0,
    val noDateCount: Int = 0,
    val outOfIntervalCount: Int = 0,
    /** Odabrane datoteke (identitet = URI, jedinstven za svaku datoteku). */
    val selected: Set<String> = emptySet(),
    /** Ručno promijenjeni ciljni datumi po URI-ju datoteke. */
    val overrides: Map<String, Long> = emptyMap(),
    val running: Boolean = false,
    val progressDone: Int = 0,
    val progressTotal: Int = 0,
    /** Trenutačna serija i ukupan broj serija (obrada u dijelovima). */
    val batch: Int = 0,
    val batchCount: Int = 0,
    val report: List<DateWriteResult>? = null,
    /** Datoteke koje nisu obrađene jer je korisnik odbio odobrenje. */
    val notProcessed: Int = 0,
    /** Sistemski dijalog za odobrenje izmjene (bez pristupa svim datotekama). */
    val writeRequest: IntentSender? = null
)

/**
 * Ispravak datuma po nazivu: analiza, odabir, upis, izvještaj.
 *
 * Velik broj datoteka obrađuje se u serijama od [BATCH]: Androidov zahtjev za odobrenje izmjene
 * (MediaStore.createWriteRequest) s nekoliko tisuća datoteka premašuje ograničenje veličine poruke
 * među procesima i ruši aplikaciju. Uz "Pristup svim datotekama" odobrenje nije potrebno.
 */
class DateFixViewModel(private val c: AppContainer) : ViewModel() {
    private val writer = DateWriter(c.context)

    val prefs: StateFlow<DateFixPrefs> = c.features.dateFix.stateIn(viewModelScope, SharingStarted.Eagerly, DateFixPrefs())

    private val _ui = MutableStateFlow(DateFixUi())
    val ui: StateFlow<DateFixUi> = _ui.asStateFlow()

    private var consent: CompletableDeferred<Boolean>? = null
    private var requestLaunched = false

    fun update(t: (DateFixPrefs) -> DateFixPrefs) {
        viewModelScope.launch { c.features.updateDateFix(t) }
    }

    /** Odabir vrsta (fotografije / videozapisi); barem jedna ostaje uključena. Zatim se ponovno učitavaju mape. */
    fun setTypes(photos: Boolean, videos: Boolean) {
        if (!photos && !videos) return
        viewModelScope.launch {
            c.features.updateDateFix { it.copy(includePhotos = photos, includeVideos = videos) }
            loadFolders()
        }
    }

    fun loadFolders() {
        viewModelScope.launch {
            val p = c.features.currentDateFix()
            val list = withContext(Dispatchers.IO) { DateFixMedia.folders(c.context, p.includePhotos, p.includeVideos) }
            _ui.update { it.copy(folders = list) }
        }
    }

    fun analyze() {
        if (_ui.value.analyzing || _ui.value.running) return
        _ui.update { it.copy(analyzing = true, report = null, notProcessed = 0) }
        viewModelScope.launch {
            val p = c.features.currentDateFix()
            val allFiles = StorageAccess.hasAllFilesAccess()
            val settings = DateFixSettings(
                from = if (p.intervalEnabled) p.from else null,
                to = if (p.intervalEnabled) p.to else null,
                basis = p.basis,
                checkTaken = p.writeMetadata,
                // Datum izmjene provjerava se samo ako ga je moguće i promijeniti.
                checkModified = p.writeModified && allFiles,
                compareTime = p.compareTime
            )
            val items = withContext(Dispatchers.Default) {
                val files = DateFixMedia.files(c.context, p.folders, p.includePhotos, p.includeVideos)
                DateFixPlanner.plan(files, NameDateParser(p.order, p.patterns, p.timestamps), settings, ZoneId.systemDefault())
            }
            val toFix = items.filter { it.status == DateFixStatus.NEEDS_FIX }
                .distinctBy { it.file.uri }
                .sortedWith(compareBy({ it.file.relativeDir }, { it.file.name }))
            _ui.update {
                it.copy(
                    analyzing = false, analyzed = true, toFix = toFix,
                    okCount = items.count { i -> i.status == DateFixStatus.OK },
                    noDateCount = items.count { i -> i.status == DateFixStatus.NO_DATE_IN_NAME },
                    outOfIntervalCount = items.count { i -> i.status == DateFixStatus.OUT_OF_INTERVAL },
                    selected = toFix.map { i -> i.file.uri }.toHashSet(),
                    overrides = emptyMap()
                )
            }
        }
    }

    fun toggle(id: String) = _ui.update { s ->
        s.copy(selected = if (id in s.selected) s.selected - id else s.selected + id)
    }

    fun selectAll(all: Boolean) = _ui.update { s -> s.copy(selected = if (all) s.toFix.map { it.file.uri }.toHashSet() else emptySet()) }

    fun override(id: String, millis: Long) = _ui.update { s -> s.copy(overrides = s.overrides + (id to millis), selected = s.selected + id) }

    fun target(item: DateFixItem): Long? = _ui.value.overrides[item.file.uri] ?: item.targetMillis

    /** Pokreće ispravak odabranih, u serijama. */
    fun fixSelected() {
        val s = _ui.value
        if (s.running) return
        val items = s.toFix.filter { it.file.uri in s.selected && target(it) != null }
        if (items.isEmpty()) return
        val batches = items.chunked(BATCH)
        _ui.update { it.copy(running = true, progressDone = 0, progressTotal = items.size, batch = 0, batchCount = batches.size, report = null, notProcessed = 0) }
        viewModelScope.launch {
            val p = c.features.currentDateFix()
            val results = ArrayList<DateWriteResult>(items.size)
            var done = 0
            var declined = false
            for ((index, batch) in batches.withIndex()) {
                _ui.update { it.copy(batch = index + 1) }
                val needRequest = withContext(Dispatchers.IO) { batch.filter { !writer.canWriteDirect(it.file) } }
                if (needRequest.isNotEmpty()) {
                    val approved = askPermission(needRequest.map { Uri.parse(it.file.uri) })
                    if (!approved) { declined = true; break }
                }
                withContext(Dispatchers.IO) {
                    for (item in batch) {
                        val r = try {
                            writer.write(item.file, target(item)!!, p.writeMetadata, p.writeModified)
                        } catch (t: Throwable) {
                            // I neočekivana pogreška (npr. nedostatak memorije kod oštećene datoteke) ne ruši obradu.
                            DateWriteResult(item.file, false, false, t.message ?: t.javaClass.simpleName)
                        }
                        results += r
                        done++
                        if (done % 25 == 0 || done == items.size) _ui.update { it.copy(progressDone = done) }
                    }
                }
            }
            val fixed = results.filter { it.ok }.map { it.file.uri }.toHashSet()
            _ui.update {
                it.copy(
                    running = false, report = results, notProcessed = if (declined) items.size - done else 0,
                    toFix = it.toFix.filter { i -> i.file.uri !in fixed },
                    selected = it.selected - fixed
                )
            }
        }
    }

    /** Sistemski dijalog "Dopusti izmjenu"; čeka odgovor korisnika. */
    private suspend fun askPermission(uris: List<Uri>): Boolean {
        val pi = try {
            MediaStore.createWriteRequest(c.context.contentResolver, uris)
        } catch (e: Exception) {
            return false
        }
        val d = CompletableDeferred<Boolean>()
        consent = d
        requestLaunched = false
        _ui.update { it.copy(writeRequest = pi.intentSender) }
        return d.await()
    }

    /** Vraća true samo jednom po zahtjevu – sprječava dvostruki dijalog nakon okretanja zaslona. */
    fun claimRequestLaunch(): Boolean {
        if (requestLaunched) return false
        requestLaunched = true
        return true
    }

    fun onWriteRequestResult(approved: Boolean) {
        _ui.update { it.copy(writeRequest = null) }
        consent?.complete(approved)
        consent = null
    }

    fun closeReport() = _ui.update { it.copy(report = null, notProcessed = 0) }

    companion object {
        /** Veličina serije – dovoljno mala da zahtjev za odobrenje ne premaši ograničenje sustava. */
        const val BATCH = 400
    }
}
