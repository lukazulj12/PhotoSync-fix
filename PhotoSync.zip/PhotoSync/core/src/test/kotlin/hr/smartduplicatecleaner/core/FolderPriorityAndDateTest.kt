package hr.smartduplicatecleaner.core

import hr.smartduplicatecleaner.core.Fixtures.DAY
import hr.smartduplicatecleaner.core.Fixtures.JAN_2023
import hr.smartduplicatecleaner.core.Fixtures.OCT_2026
import hr.smartduplicatecleaner.core.Fixtures.file
import hr.smartduplicatecleaner.core.logic.KeepSelector
import hr.smartduplicatecleaner.core.logic.ReasonCode
import hr.smartduplicatecleaner.core.logic.Suggestion
import hr.smartduplicatecleaner.core.model.CriterionType
import hr.smartduplicatecleaner.core.model.DuplicateGroup
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.FolderPriority
import hr.smartduplicatecleaner.core.model.GroupMember
import hr.smartduplicatecleaner.core.model.GroupType
import hr.smartduplicatecleaner.core.model.KeepRules
import hr.smartduplicatecleaner.core.model.ScanSettings
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.scan.CancelToken
import hr.smartduplicatecleaner.core.scan.ScanEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Prioritet mapa (3 povlaštene, 3 podređene) i vremenski interval skeniranja. */
class FolderPriorityAndDateTest {
    private val wa = "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images/"

    private fun group(vararg f: ScannedFile) =
        DuplicateGroup("g", GroupType.EXACT, FileCategory.IMAGE, f.map { GroupMember(it.key, 0) })

    private fun kept(rules: KeepRules, vararg f: ScannedFile): String? =
        KeepSelector.decide(group(*f), f.associateBy { it.key }, rules)
            .members.singleOrNull { it.suggestion == Suggestion.KEEP }?.fileKey

    @Test
    fun scoring_orderAndSubfolders() {
        val pref = listOf("DCIM/Camera/", "Pictures/Screenshots/", wa)
        val dem = listOf("Download/", "Pictures/Telegram/", "Documents/")
        assertEquals(3, FolderPriority.score("DCIM/Camera/", pref, dem))
        assertEquals(3, FolderPriority.score("dcim/camera/2023/", pref, dem)) // podmapa, mala slova
        assertEquals(2, FolderPriority.score("Pictures/Screenshots/", pref, dem))
        assertEquals(1, FolderPriority.score(wa + "Sent/", pref, dem))
        assertEquals(0, FolderPriority.score("Pictures/", pref, dem))
        assertEquals(-3, FolderPriority.score("Download/", pref, dem))
        assertEquals(-2, FolderPriority.score("Pictures/Telegram/", pref, dem))
        assertEquals(-1, FolderPriority.score("Documents/x/", pref, dem))
        // Specifičnija putanja ima prednost kad se mapa nalazi na oba popisa.
        assertEquals(1, FolderPriority.score("Download/Važno/", listOf("x/", "y/", "Download/Važno/"), listOf("Download/")))
    }

    @Test
    fun preferredOrder_decidesKeeper_evenAgainstOlderDate() {
        val camera = file("DCIM/Camera/a.jpg", 100, taken = OCT_2026)
        val shots = file("Pictures/Screenshots/a.jpg", 100, taken = JAN_2023)
        val whats = file(wa + "a.jpg", 100, taken = JAN_2023 - DAY)
        val rules = KeepRules(preferredFolders = listOf("DCIM/Camera/", "Pictures/Screenshots/", wa))
        assertEquals(camera.key, kept(rules, camera, shots, whats))
        assertEquals(shots.key, kept(rules, shots, whats))
        val d = KeepSelector.decide(group(camera, whats), listOf(camera, whats).associateBy { it.key }, rules)
        val keep = d.members.single { it.suggestion == Suggestion.KEEP }
        assertTrue(keep.reasons.any { it.code == ReasonCode.KEEP_FOLDER_PRIORITY && it.arg == "DCIM/Camera/" })
        val del = d.members.single { it.suggestion == Suggestion.DELETE }
        assertTrue(del.reasons.any { it.code == ReasonCode.DEL_FOLDER_PRIORITY && it.arg == wa })
    }

    @Test
    fun demotedOrder_deletesFromMostSubordinateFirst() {
        val normal = file("Pictures/a.jpg", 100, taken = JAN_2023)
        val dl = file("Download/a.jpg", 100, taken = JAN_2023)
        val tg = file("Pictures/Telegram/a.jpg", 100, taken = JAN_2023)
        val rules = KeepRules(demotedFolders = listOf("Download/", "Pictures/Telegram/"))
        assertEquals(normal.key, kept(rules, normal, dl, tg))
        // Bez obične mape: zadržava se manje podređena (Telegram), Download se briše.
        val d = KeepSelector.decide(group(dl, tg), listOf(dl, tg).associateBy { it.key }, rules)
        assertEquals(setOf(dl.key), d.suggestedDeleteKeys)
        val keep = d.members.single { it.suggestion == Suggestion.KEEP }
        assertTrue(keep.reasons.any { it.code == ReasonCode.KEEP_FOLDER_PRIORITY && it.arg == null })
    }

    @Test
    fun folderRule_canBeMovedBelowDate_orDisabled() {
        val camera = file("DCIM/Camera/a.jpg", 100, taken = OCT_2026)
        val other = file("Pictures/a.jpg", 100, taken = JAN_2023)
        val base = KeepRules(preferredFolders = listOf("DCIM/Camera/"))
        assertEquals(camera.key, kept(base, camera, other))
        assertEquals(other.key, kept(base.copy(order = listOf(CriterionType.DATE, CriterionType.FOLDERS)), camera, other))
        assertEquals(other.key, kept(base.copy(useFolderPriority = false), camera, other))
        // Ista razina prioriteta → odlučuju sljedeća pravila.
        val camera2 = file("DCIM/Camera/b.jpg", 100, taken = JAN_2023)
        assertEquals(camera2.key, kept(base, camera, camera2))
    }

    @Test
    fun dateRange_onlyFilesCreatedInInterval_areScanned() {
        val inside1 = file("Documents/r1.pdf", 500, modified = JAN_2023)
        val inside2 = file("Download/r1.pdf", 500, modified = JAN_2023 + DAY)
        val outside1 = file("Documents/old.pdf", 700, modified = JAN_2023 - 400 * DAY)
        val outside2 = file("Download/old.pdf", 700, modified = JAN_2023 - 400 * DAY)
        val photo1 = file("DCIM/p.jpg", 900, modified = OCT_2026)
        val photo2 = file("Pictures/p.jpg", 900, modified = OCT_2026)
        val all = listOf(inside1, inside2, outside1, outside2, photo1, photo2)
        val settings = ScanSettings(dateFrom = JAN_2023 - DAY, dateTo = JAN_2023 + 2 * DAY)
        val engine = ScanEngine(listOf(FakeSource("s", all)), FakeContent())
        val r = engine.run(settings, KeepRules(), CancelToken.NONE)
        assertEquals(setOf(inside1.key, inside2.key), r.groups.single().fileKeys.toSet())
        assertEquals(4, r.stats.skippedByDate)
        // Samo za dokumente: fotografije se skeniraju bez obzira na datum.
        val docsOnly = settings.copy(dateFilterCategories = setOf(FileCategory.DOCUMENT))
        val r2 = engine.run(docsOnly, KeepRules(), CancelToken.NONE)
        assertEquals(2, r2.groups.size)
        assertEquals(2, r2.stats.skippedByDate)
    }

    @Test
    fun dateRange_usesEarliestKnownDate_notCopyDate() {
        // Kopirana stara fotografija: datum dodavanja nov, datum snimanja star → izvan intervala 2026.
        val copied = file("DCIM/x.jpg", 10, modified = OCT_2026, added = OCT_2026, taken = JAN_2023)
        val s = ScanSettings(dateFrom = OCT_2026 - DAY)
        assertTrue(!s.dateAccepted(FileCategory.IMAGE, listOfNotNull(copied.dateTakenMillis, copied.dateModifiedMillis).min()))
        assertTrue(s.dateAccepted(FileCategory.IMAGE, OCT_2026))
        assertTrue(!s.dateAccepted(FileCategory.IMAGE, null)) // nepoznat datum ne prolazi aktivni filtar
        assertTrue(ScanSettings().dateAccepted(FileCategory.IMAGE, null)) // bez filtra sve prolazi
        assertNull(ScanSettings().dateFrom)
    }
}
