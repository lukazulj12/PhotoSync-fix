package hr.smartduplicatecleaner.core.transfer

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.util.Collections

/**
 * Automatsko pronalaženje primatelja u lokalnoj mreži (žarišna točka jednog od mobitela ili zajednički Wi-Fi).
 * Pošiljatelj šalje kratki UDP upit na adrese za razašiljanje (broadcast), primatelj odgovara svojom adresom
 * i portom. Upit i odgovor ne sadrže kod – kod se provjerava tek pri TCP vezi (uz ograničen broj pokušaja),
 * pa se iz odgovora ne može pogoditi.
 */
object Discovery {
    const val PORT = 47655
    private val REQUEST = "PHOTOSYNC?1".toByteArray(Charsets.US_ASCII)
    private val RESPONSE = "PHOTOSYNC!1".toByteArray(Charsets.US_ASCII)

    /** Pronađeni primatelj. */
    data class Found(val address: InetAddress, val tcpPort: Int, val name: String)

    /**
     * Odgovara na upite dok se ne zaustavi. [reply] šalje odgovor (Android ga šalje kroz socket vezan
     * uz Wi-Fi mrežu kad je to potrebno).
     */
    class Responder(
        private val socket: DatagramSocket,
        private val tcpPort: Int,
        private val name: String,
        private val reply: (DatagramPacket) -> Unit = { socket.send(it) }
    ) {
        @Volatile private var running = false
        private var thread: Thread? = null

        fun start() {
            running = true
            thread = Thread({
                val buf = ByteArray(256)
                while (running) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        socket.receive(p)
                        if (p.length == REQUEST.size && buf.copyOf(REQUEST.size).contentEquals(REQUEST)) {
                            val nameBytes = name.take(40).toByteArray(Charsets.UTF_8)
                            val data = RESPONSE + byteArrayOf((tcpPort shr 8).toByte(), tcpPort.toByte()) + nameBytes
                            reply(DatagramPacket(data, data.size, p.address, p.port))
                        }
                    } catch (e: SocketTimeoutException) {
                        // provjera zastavice running
                    } catch (e: Exception) {
                        if (!running) break
                    }
                }
            }, "photosync-discovery").apply { isDaemon = true; start() }
        }

        fun stop() {
            running = false
            try { socket.close() } catch (e: Exception) { }
        }
    }

    /**
     * Šalje upite na sve zadane adrese kroz zadane sokete i skuplja odgovore do isteka [timeoutMs].
     * Vraća čim stigne prvi odgovor i protekne još [settleMs] (ako u mreži ima više primatelja).
     */
    fun find(targets: List<Pair<DatagramSocket, List<InetSocketAddress>>>, timeoutMs: Long = 4000, settleMs: Long = 400): List<Found> {
        val found = Collections.synchronizedMap(LinkedHashMap<String, Found>())
        val end = System.currentTimeMillis() + timeoutMs
        val firstAt = java.util.concurrent.atomic.AtomicLong(0)
        val threads = targets.map { (socket, addresses) ->
            Thread({
                try {
                    socket.broadcast = true
                    socket.soTimeout = 250
                    val buf = ByteArray(256)
                    var lastSend = 0L
                    while (System.currentTimeMillis() < end) {
                        val now = System.currentTimeMillis()
                        if (firstAt.get() > 0 && now - firstAt.get() > settleMs) break
                        if (now - lastSend > 700) {
                            lastSend = now
                            for (a in addresses) {
                                try { socket.send(DatagramPacket(REQUEST, REQUEST.size, a)) } catch (e: Exception) { }
                            }
                        }
                        try {
                            val p = DatagramPacket(buf, buf.size)
                            socket.receive(p)
                            if (p.length >= RESPONSE.size + 2 && buf.copyOf(RESPONSE.size).contentEquals(RESPONSE)) {
                                val port = ((buf[RESPONSE.size].toInt() and 0xFF) shl 8) or (buf[RESPONSE.size + 1].toInt() and 0xFF)
                                val name = String(buf, RESPONSE.size + 2, p.length - RESPONSE.size - 2, Charsets.UTF_8)
                                found.putIfAbsent(p.address.hostAddress ?: "", Found(p.address, port, name))
                                firstAt.compareAndSet(0, System.currentTimeMillis())
                            }
                        } catch (e: SocketTimeoutException) {
                        }
                    }
                } catch (e: Exception) {
                    // Soket nedostupan – ostali soketi i dalje traže.
                }
            }, "photosync-find").apply { isDaemon = true; start() }
        }
        threads.forEach { it.join(timeoutMs + 1000) }
        return synchronized(found) { found.values.toList() }
    }
}
