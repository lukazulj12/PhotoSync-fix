package hr.smartduplicatecleaner.core.transfer

import hr.smartduplicatecleaner.core.logic.FileClassifier
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.ScannedFile
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Vrste podataka koje se mogu prenijeti. */
enum class TransferCategory { PHOTOS, VIDEOS, AUDIO, DOCUMENTS, ARCHIVES, APK_FILES, APPS, OTHER }

object TransferClassifier {
    private val APK = setOf("apk", "apks", "xapk", "apkm")

    fun of(file: ScannedFile): TransferCategory {
        if (FileClassifier.extension(file.name) in APK) return TransferCategory.APK_FILES
        return when (file.category) {
            FileCategory.IMAGE -> TransferCategory.PHOTOS
            FileCategory.VIDEO -> TransferCategory.VIDEOS
            FileCategory.AUDIO -> TransferCategory.AUDIO
            FileCategory.DOCUMENT -> TransferCategory.DOCUMENTS
            FileCategory.ARCHIVE -> TransferCategory.ARCHIVES
            FileCategory.OTHER -> TransferCategory.OTHER
        }
    }
}

/** Jedna datoteka u prijenosu. */
data class TransferItem(
    val id: Int,
    /** Relativna mapa na pošiljatelju, npr. "DCIM/Camera/" (završava s '/', ili prazno). */
    val relativeDir: String,
    val name: String,
    val size: Long,
    val modified: Long?,
    val taken: Long?,
    val category: TransferCategory,
    val mime: String?,
    /** Lokalna referenca pošiljatelja (URI ili putanja) – NE šalje se drugom uređaju. */
    val sourceRef: String = ""
)

data class TransferProgress(
    val filesDone: Int,
    val filesTotal: Int,
    val bytesDone: Long,
    val bytesTotal: Long,
    val failed: Int,
    val startedAt: Long
) {
    /** Prosječna brzina u bajtovima po sekundi. */
    fun bytesPerSecond(now: Long = System.currentTimeMillis()): Long {
        val ms = (now - startedAt).coerceAtLeast(1)
        return bytesDone * 1000 / ms
    }
}

data class TransferResult(
    val succeeded: List<TransferItem>,
    val failed: List<Pair<TransferItem, String>>,
    val skipped: List<TransferItem>,
    val bytes: Long,
    val millis: Long,
    val cancelled: Boolean
)

class TransferException(val reason: Reason, val freeBytes: Long = -1, cause: Throwable? = null) :
    Exception(reason.name, cause) {
    enum class Reason { AUTH_FAILED, NO_SPACE, BUSY, CONNECTION, CANCELLED, PROTOCOL }
}

/** Izvor datoteka na pošiljatelju. */
fun interface TransferSource {
    fun open(item: TransferItem): InputStream
}

/** Datoteka koja se upravo prima. [commit] zatvara i trajno sprema, [abort] briše djelomični sadržaj. */
interface IncomingFile {
    val output: OutputStream
    fun commit()
    fun abort()
}

/** Odredište na primatelju. Mora biti sigurno za istovremeni rad više dretvi. */
interface TransferSink {
    /** Slobodan prostor (već umanjen za sigurnosnu rezervu). */
    fun freeBytes(): Long
    /** Treba li datoteku preskočiti (npr. već postoji ista). */
    fun shouldSkip(item: TransferItem): Boolean
    fun create(item: TransferItem): IncomingFile
}

/**
 * Kod za uparivanje: 4 znamenke (npr. "4821"), novi za svako primanje. Iz njega se izvodi ključ za provjeru
 * identiteta (HMAC), a sam kod se nikad ne šalje mrežom. Primatelj nakon [MAX_FAILED_ATTEMPTS] pogrešnih
 * pokušaja prestaje primati, pa se kod ne može pogoditi isprobavanjem.
 */
object PairingCode {
    const val LENGTH = 4
    const val PORT = 47654
    const val MAX_FAILED_ATTEMPTS = 10

    fun generate(random: SecureRandom = SecureRandom()): String = "%04d".format(random.nextInt(10_000))

    /** Iz unosa uzima samo znamenke; null ako nisu točno 4. */
    fun normalize(input: String): String? {
        val s = input.filter { it.isDigit() }
        return if (s.length == LENGTH) s else null
    }

    fun display(code: String): String = code

    fun authKey(code: String): ByteArray = sha256("PhotoSync-auth:$code")

    internal fun sha256(s: String): ByteArray = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
}

internal object Proto {
    val MAGIC: ByteArray = "PHOTOSY1".toByteArray(Charsets.US_ASCII)
    const val TYPE_CONTROL = 1
    const val TYPE_DATA = 2
    const val OK = 0
    const val AUTH_FAIL = 1
    const val NO_SPACE = 2
    const val BUSY = 3
    const val BAD = 4
    const val END = -1
    const val DONE = 9
    const val BUFFER = 1 shl 20
    const val SOCKET_BUFFER = 4 shl 20
    const val MAX_ITEMS = 5_000_000

    fun label(type: Int) = if (type == TYPE_CONTROL) "ctrl" else "data"

    fun hmac(key: ByteArray, label: String, nonce: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        mac.update(label.toByteArray(Charsets.US_ASCII))
        return mac.doFinal(nonce)
    }

    fun writeItem(out: java.io.DataOutputStream, it: TransferItem) {
        out.writeInt(it.id)
        out.writeUTF(it.relativeDir)
        out.writeUTF(it.name)
        out.writeLong(it.size)
        out.writeLong(it.modified ?: -1)
        out.writeLong(it.taken ?: -1)
        out.writeByte(it.category.ordinal)
        out.writeUTF(it.mime ?: "")
    }

    fun readItem(inp: java.io.DataInputStream): TransferItem {
        val id = inp.readInt()
        val dir = inp.readUTF()
        val name = inp.readUTF()
        val size = inp.readLong()
        val modified = inp.readLong().takeIf { it > 0 }
        val taken = inp.readLong().takeIf { it > 0 }
        val cat = TransferCategory.entries.getOrElse(inp.readUnsignedByte()) { TransferCategory.OTHER }
        val mime = inp.readUTF().ifEmpty { null }
        if (size < 0) throw java.io.IOException("negative size")
        return TransferItem(id, sanitizeDir(dir), sanitizeName(name), size, modified, taken, cat, mime)
    }

    /** Zaštita: naziv bez znakova putanje. */
    fun sanitizeName(name: String): String {
        val n = name.replace('/', '_').replace('\\', '_').replace("\u0000", "").trim()
        return if (n.isEmpty() || n == "." || n == "..") "file" else n
    }

    /** Zaštita od "../" i apsolutnih putanja. */
    fun sanitizeDir(dir: String): String {
        val parts = dir.replace('\\', '/').split('/')
            .map { it.replace("\u0000", "").trim() }
            .filter { it.isNotEmpty() && it != "." && it != ".." }
        return if (parts.isEmpty()) "" else parts.joinToString("/") + "/"
    }
}
