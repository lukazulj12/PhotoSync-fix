package hr.smartduplicatecleaner.core.hash

import hr.smartduplicatecleaner.core.scan.CancelToken
import java.io.InputStream
import java.security.MessageDigest

/** Streaming SHA-256 – datoteka se nikad ne učitava cijela u memoriju. */
object Sha256 {
    private const val BUFFER = 64 * 1024

    /** Puni SHA-256 sadržaja, heksadecimalno (mala slova). */
    fun hash(input: InputStream, cancel: CancelToken = CancelToken.NONE): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(BUFFER)
        input.use { stream ->
            while (true) {
                cancel.throwIfCancelled()
                val read = stream.read(buffer)
                if (read < 0) break
                if (read > 0) digest.update(buffer, 0, read)
            }
        }
        return digest.digest().toHex()
    }

    /**
     * Brzi predfilter: SHA-256 prvih [limit] bajtova. Datoteke čiji se početak razlikuje
     * sigurno nisu identične, pa za njih ne treba čitati cijeli sadržaj.
     */
    fun partialHash(input: InputStream, limit: Int = BUFFER): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(BUFFER)
        var remaining = limit
        input.use { stream ->
            while (remaining > 0) {
                val read = stream.read(buffer, 0, minOf(buffer.size, remaining))
                if (read < 0) break
                digest.update(buffer, 0, read)
                remaining -= read
            }
        }
        return digest.digest().toHex()
    }

    fun ByteArray.toHex(): String {
        val chars = CharArray(size * 2)
        val hex = "0123456789abcdef"
        for (i in indices) {
            val v = this[i].toInt() and 0xFF
            chars[i * 2] = hex[v ushr 4]
            chars[i * 2 + 1] = hex[v and 0x0F]
        }
        return String(chars)
    }
}
