package hr.smartduplicatecleaner.core.logic

import hr.smartduplicatecleaner.core.model.FileCategory
import java.util.Locale

/** Razvrstavanje datoteka u kategorije prema MIME tipu, a ako ga nema – prema ekstenziji. */
object FileClassifier {
    private val IMAGE = setOf("jpg", "jpeg", "png", "webp", "heic", "heif", "gif", "bmp", "dng", "avif")
    private val VIDEO = setOf("mp4", "mov", "mkv", "avi", "3gp", "webm", "m4v", "wmv", "flv", "ts")
    private val AUDIO = setOf("mp3", "wav", "aac", "flac", "ogg", "opus", "m4a", "amr", "wma", "mid", "midi")
    private val DOCUMENT = setOf(
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf", "odt", "ods", "odp",
        "csv", "epub", "md", "html", "htm", "xml", "json"
    )
    private val ARCHIVE = setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "apk")

    fun extension(name: String): String =
        name.substringAfterLast('.', "").lowercase(Locale.ROOT)

    fun classify(name: String, mimeType: String?): FileCategory {
        val mime = mimeType?.lowercase(Locale.ROOT).orEmpty()
        when {
            mime.startsWith("image/") -> return FileCategory.IMAGE
            mime.startsWith("video/") -> return FileCategory.VIDEO
            mime.startsWith("audio/") -> return FileCategory.AUDIO
        }
        val ext = extension(name)
        return when {
            ext in IMAGE -> FileCategory.IMAGE
            ext in VIDEO -> FileCategory.VIDEO
            ext in AUDIO -> FileCategory.AUDIO
            ext in DOCUMENT || mime == "application/pdf" || mime.startsWith("text/") ||
                mime.contains("officedocument") || mime.contains("msword") || mime.contains("ms-excel") ||
                mime.contains("ms-powerpoint") || mime.contains("opendocument") -> FileCategory.DOCUMENT
            ext in ARCHIVE || mime.contains("zip") || mime.contains("rar") || mime.contains("7z") ||
                mime.contains("x-tar") || mime.contains("gzip") -> FileCategory.ARCHIVE
            else -> FileCategory.OTHER
        }
    }
}
