package hr.smartduplicatecleaner.core.dates

import hr.smartduplicatecleaner.core.model.ScannedFile
import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId

/** Na koji se datum primjenjuje vremenski interval analize. */
enum class IntervalBasis {
    /** Datum zapisan u nazivu datoteke. */
    NAME_DATE,
    /** Trenutačni datum datoteke (onaj koji prikazuje galerija). */
    CURRENT_DATE
}

data class DateFixSettings(
    /** Vremenski interval (uključivo); null = bez granice. */
    val from: Long? = null,
    val to: Long? = null,
    val basis: IntervalBasis = IntervalBasis.NAME_DATE,
    /** Provjerava se datum snimanja (EXIF / metapodaci) – datum koji koristi galerija. */
    val checkTaken: Boolean = true,
    /** Provjerava se datum posljednje izmjene datoteke. */
    val checkModified: Boolean = true,
    /** Uspoređuje se i vrijeme (kad ga naziv sadrži); inače samo kalendarski dan. */
    val compareTime: Boolean = false
)

enum class DateFixStatus {
    /** Datum datoteke ne odgovara datumu iz naziva. */
    NEEDS_FIX,
    /** Datum odgovara. */
    OK,
    /** U nazivu nema prepoznatljivog datuma – datoteka se preskače. */
    NO_DATE_IN_NAME,
    /** Izvan odabranog vremenskog intervala. */
    OUT_OF_INTERVAL
}

data class DateFixItem(
    val file: ScannedFile,
    val nameDate: NameDate?,
    /** Datum koji će se upisati (milisekunde), ili null ako nema datuma u nazivu. */
    val targetMillis: Long?,
    /** Datum koji galerija trenutačno prikazuje (datum snimanja, inače datum izmjene). */
    val shownMillis: Long?,
    val status: DateFixStatus,
    val takenDiffers: Boolean,
    val modifiedDiffers: Boolean
)

/** Usporedba datuma datoteka s datumima iz njihovih naziva. */
object DateFixPlanner {
    private val NOON: LocalTime = LocalTime.NOON

    fun plan(
        files: List<ScannedFile>,
        parser: NameDateParser,
        settings: DateFixSettings,
        zone: ZoneId = ZoneId.systemDefault()
    ): List<DateFixItem> = files.map { analyze(it, parser, settings, zone) }

    fun analyze(file: ScannedFile, parser: NameDateParser, settings: DateFixSettings, zone: ZoneId): DateFixItem {
        val shown = file.dateTakenMillis?.takeIf { it > 0 } ?: file.dateModifiedMillis?.takeIf { it > 0 }
        val nameDate = parser.parse(file.name)
            ?: return DateFixItem(file, null, null, shown, DateFixStatus.NO_DATE_IN_NAME, takenDiffers = false, modifiedDiffers = false)

        // Ako naziv nema vrijeme, zadržava se dosadašnje vrijeme u danu (čuva redoslijed u galeriji), inače podne.
        val defaultTime = shown?.let { Instant.ofEpochMilli(it).atZone(zone).toLocalTime().withNano(0) } ?: NOON
        val target = nameDate.toDateTime(defaultTime).atZone(zone).toInstant().toEpochMilli()

        val basisValue = if (settings.basis == IntervalBasis.NAME_DATE) target else shown
        val hasInterval = settings.from != null || settings.to != null
        if (hasInterval) {
            val outside = basisValue == null ||
                (settings.from != null && basisValue < settings.from) ||
                (settings.to != null && basisValue > settings.to)
            if (outside) {
                return DateFixItem(file, nameDate, target, shown, DateFixStatus.OUT_OF_INTERVAL, takenDiffers = false, modifiedDiffers = false)
            }
        }

        val withTime = settings.compareTime && nameDate.time != null
        val takenDiffers = settings.checkTaken && differs(shown, target, withTime, zone)
        val modifiedDiffers = settings.checkModified && differs(file.dateModifiedMillis, target, withTime, zone)
        val status = if (takenDiffers || modifiedDiffers) DateFixStatus.NEEDS_FIX else DateFixStatus.OK
        return DateFixItem(file, nameDate, target, shown, status, takenDiffers, modifiedDiffers)
    }

    private fun differs(current: Long?, target: Long, withTime: Boolean, zone: ZoneId): Boolean {
        if (current == null || current <= 0) return true
        if (withTime) return kotlin.math.abs(current - target) > 60_000L
        val a = Instant.ofEpochMilli(current).atZone(zone).toLocalDate()
        val b = Instant.ofEpochMilli(target).atZone(zone).toLocalDate()
        return a != b
    }
}
