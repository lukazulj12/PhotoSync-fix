package hr.smartduplicatecleaner.core.media

import java.io.IOException
import java.io.RandomAccessFile

/** Nasumični pristup bajtovima datoteke (RandomAccessFile na računalu, pread/pwrite na Androidu). */
interface RandomAccessIO {
    val size: Long
    fun read(position: Long, buffer: ByteArray, offset: Int, length: Int): Int
    fun write(position: Long, buffer: ByteArray, offset: Int, length: Int)
}

class FileRandomAccessIO(private val file: RandomAccessFile) : RandomAccessIO {
    override val size: Long get() = file.length()
    override fun read(position: Long, buffer: ByteArray, offset: Int, length: Int): Int {
        file.seek(position)
        return file.read(buffer, offset, length)
    }
    override fun write(position: Long, buffer: ByteArray, offset: Int, length: Int) {
        file.seek(position)
        file.write(buffer, offset, length)
    }
}

/**
 * Čitanje i promjena datuma stvaranja u MP4 / MOV / 3GP videozapisima.
 *
 * Datum je zapisan u kutijama mvhd (cijeli film), tkhd (svaka staza) i mdhd (medij staze) kao broj sekundi
 * od 1. 1. 1904. (UTC). Mijenjaju se samo ta polja na istom mjestu – veličina datoteke i ostali sadržaj
 * ostaju nepromijenjeni, pa je postupak brz i siguran i za velike videozapise.
 */
object Mp4Dates {
    /** Sekunde između 1. 1. 1904. i 1. 1. 1970. */
    const val EPOCH_1904_OFFSET = 2_082_844_800L

    private val CONTAINERS = setOf("moov", "trak", "mdia")
    private val TIMED = setOf("mvhd", "tkhd", "mdhd")

    class NotMp4Exception : IOException("Nije MP4/MOV datoteka ili nema kutiju mvhd")

    /** Datum stvaranja iz kutije mvhd (milisekunde UTC) ili null. */
    fun read(io: RandomAccessIO): Long? {
        var result: Long? = null
        walk(io, 0, io.size, 0) { type, pos, payload ->
            if (type == "mvhd" && result == null) {
                val header = ByteArray(20)
                if (readFully(io, pos, header, minOf(20L, payload).toInt())) {
                    val version = header[0].toInt() and 0xFF
                    val seconds = if (version == 1) u64(header, 4) else u32(header, 4)
                    if (seconds > 0) result = (seconds - EPOCH_1904_OFFSET) * 1000
                }
            }
        }
        return result
    }

    /**
     * Upisuje datum stvaranja i izmjene u mvhd, tkhd i mdhd.
     * @return broj promijenjenih kutija
     * @throws NotMp4Exception ako datoteka nema kutiju mvhd
     */
    fun write(io: RandomAccessIO, utcMillis: Long): Int {
        val seconds = utcMillis / 1000 + EPOCH_1904_OFFSET
        require(seconds in 0..0xFFFF_FFFFL) { "Datum izvan raspona MP4 zapisa" }
        // 1. prolaz: samo pronalaženje polja (ništa se ne mijenja dok struktura nije potvrđena).
        val targets = mutableListOf<Pair<Long, Int>>()
        var foundMvhd = false
        walk(io, 0, io.size, 0) { type, pos, payload ->
            if (type !in TIMED) return@walk
            val head = ByteArray(1)
            if (!readFully(io, pos, head, 1)) return@walk
            val version = head[0].toInt() and 0xFF
            if (version == 1 && payload >= 20 || version == 0 && payload >= 12) {
                targets += pos to version
                if (type == "mvhd") foundMvhd = true
            }
        }
        if (!foundMvhd) throw NotMp4Exception()
        // 2. prolaz: upis. Iza verzije (1 bajt) i zastavica (3 bajta) slijede datum stvaranja i datum izmjene.
        for ((pos, version) in targets) {
            val buf: ByteArray
            if (version == 1) {
                buf = ByteArray(16); putU64(buf, 0, seconds); putU64(buf, 8, seconds)
            } else {
                buf = ByteArray(8); putU32(buf, 0, seconds); putU32(buf, 4, seconds)
            }
            io.write(pos + 4, buf, 0, buf.size)
        }
        return targets.size
    }

    /** Obilazak kutija; [visit] dobiva vrstu, početak sadržaja i duljinu sadržaja. */
    private fun walk(io: RandomAccessIO, start: Long, end: Long, depth: Int, visit: (String, Long, Long) -> Unit) {
        if (depth > 8) return
        var pos = start
        val header = ByteArray(16)
        while (pos + 8 <= end) {
            if (!readFully(io, pos, header, 8)) return
            var size = u32(header, 0)
            val type = String(header, 4, 4, Charsets.ISO_8859_1)
            var headerSize = 8L
            if (size == 1L) {
                if (!readFully(io, pos + 8, header, 8)) return
                size = u64(header, 0)
                headerSize = 16
            } else if (size == 0L) {
                size = end - pos
            }
            if (size < headerSize || pos + size > end) return // oštećena ili nepoznata struktura – prekid bez izmjena
            val payloadStart = pos + headerSize
            val payload = size - headerSize
            if (type in CONTAINERS) walk(io, payloadStart, pos + size, depth + 1, visit)
            else visit(type, payloadStart, payload)
            pos += size
        }
    }

    private fun readFully(io: RandomAccessIO, pos: Long, buf: ByteArray, len: Int): Boolean {
        var done = 0
        while (done < len) {
            val n = io.read(pos + done, buf, done, len - done)
            if (n <= 0) return false
            done += n
        }
        return true
    }

    private fun u32(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 0xFF) shl 24) or ((b[o + 1].toLong() and 0xFF) shl 16) or
            ((b[o + 2].toLong() and 0xFF) shl 8) or (b[o + 3].toLong() and 0xFF)

    private fun u64(b: ByteArray, o: Int): Long = (u32(b, o) shl 32) or u32(b, o + 4)

    private fun putU32(b: ByteArray, o: Int, v: Long) {
        b[o] = (v ushr 24).toByte(); b[o + 1] = (v ushr 16).toByte(); b[o + 2] = (v ushr 8).toByte(); b[o + 3] = v.toByte()
    }

    private fun putU64(b: ByteArray, o: Int, v: Long) {
        putU32(b, o, v ushr 32); putU32(b, o + 4, v and 0xFFFF_FFFFL)
    }
}
