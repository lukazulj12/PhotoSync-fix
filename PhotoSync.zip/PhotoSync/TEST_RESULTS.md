# Rezultati testova – PhotoSync&fix

Datum izvođenja: 10. 11. 2026. Okruženje: Linux, OpenJDK 21, Kotlin 2.0.21, JUnit 4.13.2.

- **`core`**: 62 testa, svi prolaze (duplikati, prioritet mapa, prepoznavanje datuma u nazivima, izmjena datuma u MP4,
  prijenos preko stvarnih TCP veza na 127.0.0.1, automatsko pronalaženje primatelja, ponovno slanje neuspjelih stavki).
- **`app`**: test potpunosti hrvatskog i engleskog prijevoda (3 testa) i `tools/check_resources.py` (447 tekstova);
  provjera sintakse svih Kotlin datoteka aplikacije.
- **Nije izvršeno ovdje:** kompajliranje Android koda, izgradnja APK-a i rad na stvarnim mobitelima (Android SDK nije bio dostupan).
  GitHub workflow pokreće `:core:test :app:testFullDebugUnitTest :app:assembleFullDebug`.

## Testovi za ovu verziju

| Područje | Test | Što provjerava |
|---|---|---|
| Duplikati | `visualComparisonOff_onlyExactDuplicates` | uz isključeno „Traži slične fotografije” nema vizualnih ni sličnih grupa, ništa se ne označava osim identičnih datoteka |
| Prijenos | `pairingCode_and_classifier` | kod od 4 znamenke (0000–9999), unos samo znamenki, razvrstavanje APK/arhiva |
| | `tooManyWrongCodes_stopReceiver` | nakon 10 pogrešnih kodova primatelj se zaustavlja; ni ispravan kod više ne prolazi |
| | `portCheck_doesNotUseCodeAttempts` | rezervno traženje (otvaranje i zatvaranje veze) ne troši pokušaje koda |
| | `discovery_findsReceiver_andIgnoresGarbage` | UDP upit pronalazi primatelja (port, naziv), neispravan upit ne dobiva odgovor, bez primatelja prazan rezultat |
| | `resendFailed_secondSessionOnSameReceiver` | 2 od 12 datoteka ne uspije → ponovno slanje samo njih istom primatelju → svih 12 stiže netaknuto |
| | `parallelTransfer_allFilesArriveIntact` | 120 datoteka (0 B – 3,5 MB) preko 4 paralelne veze, bajt po bajt jednake |
| | `wrongCode_isRejected_andNothingWritten` | pogrešan kod |
| | `skipExisting_noSpace_andSourceErrors` | preskakanje postojećih, izvor nestao tijekom slanja, nema mjesta |
| | `cancel_stopsTransfer_andReceiverDiscardsPartialFiles` | otkazivanje, primatelj ne sprema djelomične datoteke |
| | `maliciousPaths_areSanitized` | "../" putanje |
| Datumi iz naziva | `userExamples`, `commonFormats`, `ddmmVsMmdd`, `customPatterns`, … | kao u prethodnoj verziji |
| MP4 datum | `writesAllDateFields_inPlace_keepingSizeAndMediaData`, `notMp4_isRejected_withoutChanges` | kao u prethodnoj verziji |

## Izlaz izvođenja

```
== core ==
OK  ScanScenariosTest.samePhysicalFileFromTwoSources_isNotItsOwnDuplicate
  OK  ScanScenariosTest.exifVersusNoExif_fallbackIsLabelled_andCaptureOnlySkips
  OK  ScanScenariosTest.recompressedSmallerCopy_isVisualDuplicate_andOlderLargerIsKept
  OK  ScanScenariosTest.sameNameIdenticalContent_isExactGroup
  OK  ScanScenariosTest.identicalPhotosDifferentNames_areFound
  OK  ScanScenariosTest.differentSizeAndResolution_rulesRespected
  OK  ScanScenariosTest.deniedSource_isReported_andOtherSourcesStillScanned
  OK  ScanScenariosTest.emptyFiles_areIgnored
  OK  ScanScenariosTest.unreadableFile_isNeverReportedAsDuplicate
  OK  ScanScenariosTest.visualComparisonOff_onlyExactDuplicates
  OK  ScanScenariosTest.categoryAndFolderFilters_applied
  OK  ScanScenariosTest.cancellation_stopsScan
  OK  ScanScenariosTest.filesAboveLimit_areExcludedAndReported
  OK  ScanScenariosTest.copiedPhotoWithNewFileDate_keepsOriginalByCaptureDate_orAsksUser
  OK  ScanScenariosTest.sameNameDifferentContent_isSameNameGroupWithoutAutoSuggestion
  OK  ScanScenariosTest.manyFiles_andOutOfMemory_handledGracefully
  OK  SelectionAndDeletionTest.undecidedGroups_neverAutoMarked
  OK  SelectionAndDeletionTest.runnerDeletesOnlyConfirmedFiles
  OK  SelectionAndDeletionTest.changedSinceScan_isNotDeleted
  OK  SelectionAndDeletionTest.manualChangeOfAutomaticSelection
  OK  SelectionAndDeletionTest.crossGroupProtection_fileInTwoGroups
  OK  SelectionAndDeletionTest.cannotMarkAllFilesInGroup
  OK  SelectionAndDeletionTest.errorsDuringDeletion_areReported_andDoNotStopOthers
  OK  SelectionAndDeletionTest.planRejectsUnknownFiles
  OK  SelectionAndDeletionTest.onlyConfirmed_ignoresVisualGroups
  OK  SelectionAndDeletionTest.corruptedSavedState_withAllMarked_isSanitized
  OK  HashAndRulesTest.missingResolution_skipsCriterion_neverGuesses
  OK  HashAndRulesTest.exifOrientation_makesRotatedCopiesMatch
  OK  HashAndRulesTest.reasonEncoding_roundTrip
  OK  HashAndRulesTest.similarGroup_isAdvisoryOnly
  OK  HashAndRulesTest.rulePriority_primarySecondaryTertiary
  OK  HashAndRulesTest.exifDateParser_validatesValues
  OK  HashAndRulesTest.similarityThreshold_mapping
  OK  HashAndRulesTest.classifier
  OK  HashAndRulesTest.newerPreference_andDisabledRules
  OK  HashAndRulesTest.formatters
  OK  HashAndRulesTest.sha256_knownVector
  OK  HashAndRulesTest.perceptualHash_robustToScaleAndRecompression_butSeparatesDifferentPhotos
  OK  FolderPriorityAndDateTest.dateRange_usesEarliestKnownDate_notCopyDate
  OK  FolderPriorityAndDateTest.preferredOrder_decidesKeeper_evenAgainstOlderDate
  OK  FolderPriorityAndDateTest.demotedOrder_deletesFromMostSubordinateFirst
  OK  FolderPriorityAndDateTest.folderRule_canBeMovedBelowDate_orDisabled
  OK  FolderPriorityAndDateTest.scoring_orderAndSubfolders
  OK  FolderPriorityAndDateTest.dateRange_onlyFilesCreatedInInterval_areScanned
  OK  NameDateTest.customPatterns
  OK  NameDateTest.ddmmVsMmdd
  OK  NameDateTest.noDateOrImplausible_returnsNull
  OK  NameDateTest.commonFormats
  OK  NameDateTest.userExamples
  OK  NameDateTest.planner_detectsMismatch_andSkipsNamesWithoutDate
  OK  Mp4DatesTest.notMp4_isRejected_withoutChanges
  OK  Mp4DatesTest.writesAllDateFields_inPlace_keepingSizeAndMediaData
  OK  TransferTest.portCheck_doesNotUseCodeAttempts
  OK  TransferTest.cancel_stopsTransfer_andReceiverDiscardsPartialFiles
  OK  TransferTest.tooManyWrongCodes_stopReceiver
  OK  TransferTest.resendFailed_secondSessionOnSameReceiver
  OK  TransferTest.parallelTransfer_allFilesArriveIntact
  OK  TransferTest.maliciousPaths_areSanitized
  OK  TransferTest.discovery_findsReceiver_andIgnoresGarbage
  OK  TransferTest.pairingCode_and_classifier
  OK  TransferTest.skipExisting_noSpace_andSourceErrors
  OK  TransferTest.wrongCode_isRejected_andNothingWritten
Ukupno: 62, neuspjelo: 0, trajanje: 3988 ms
== app (lokalizacija) ==
OK  LocalizationResourcesTest.formatArgumentsMatch
  OK  LocalizationResourcesTest.keyCroatianTermsPresent
  OK  LocalizationResourcesTest.everyStringIsTranslated
Ukupno: 3, neuspjelo: 0, trajanje: 147 ms
== provjera resursa ==
EN: 447  HR: 446  korišteno: 447  nekorišteno: []
OK – lokalizacija je potpuna i dosljedna.
```
