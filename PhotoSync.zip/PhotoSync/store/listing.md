# Tekstovi za Google Play – PhotoSync&fix

Gdje se upisuju: **Play Console → Rast korisnika → Prisutnost u trgovini → Glavni unos trgovine**
(zadani jezik npr. hrvatski, zatim *Upravljanje prijevodima → Dodaj vlastiti prijevod → engleski (en-US)*).
Ograničenja su provjerena: naziv ≤ 30, kratki opis ≤ 80, puni opis ≤ 4000 znakova.

> ⚠️ **Naziv:** „PhotoSync – Transfer Photos” (touchbyte GmbH) već postoji na Google Playu i radi sličan posao.
> Pravila Google Playa o lažnom predstavljanju (Impersonation) zabranjuju nazive zbog kojih bi korisnici mogli
> pomisliti da je aplikacija povezana s drugom. „PhotoSync&fix” je u toj sivoj zoni – ako Google odbije unos ili
> vlasnik prigovori, promijenite naziv (vidi README → *Promjena naziva*). Prijedlozi: **SnapMove**, **PicShift**,
> **FotoSeli**, **DateFix & Move**, **PhoneHop** (prije odabira provjerite na Google Playu da nisu zauzeti).

---

## 🇭🇷 Hrvatski (hr-HR)

**Naziv aplikacije (max 30) – 30 znakova:**
```
PhotoSync&fix – prijenos slika
```

**Kratki opis (max 80) – 77 znakova:**
```
Prebacite fotografije na novi mobitel, ispravite datume i obrišite duplikate.
```

**Puni opis (max 4000) – 2893 znakova:**
```
Novi mobitel? PhotoSync&fix prebacuje fotografije, videozapise i ostale datoteke sa starog mobitela na novi, vraća fotografijama ispravan datum i čisti duplikate – bez kabela, bez računala, bez interneta, bez oglasa i bez registracije.

📲 PRIJENOS NA NOVI MOBITEL
• Brzi prijenos preko Wi-Fi-ja: na jednom mobitelu uključite žarišnu točku (hotspot) – svejedno na kojem – a drugi spojite na nju. Može i isti kućni Wi-Fi.
• Kod od 4 znamenke – stari mobitel sam pronalazi novi, nema upisivanja adresa.
• Više paralelnih veza za najveću brzinu, velike datoteke idu prve.
• Odaberite što šaljete: fotografije, videozapise, audiozapise, dokumente, ZIP/RAR arhive, APK datoteke i instalirane aplikacije (kao APK).
• Odaberite vremenski interval (npr. samo fotografije iz 2025.) i odznačite mape koje ne želite.
• Fotografije mogu otići u iste mape kao na starom mobitelu (npr. DCIM/Camera), u zadanu mapu PhotoSync s podmapom za svaku vrstu ili u mapu koju sami odaberete.
• Čuva izvorni datum datoteka, pa galerija prikazuje fotografije pod pravim datumom.
• Nakon prijenosa vidite točno koje stavke nisu prenesene i jednim dodirom ih šaljete ponovno.
• Radi i s ugašenim zaslonom; preskače datoteke koje već postoje.
• Sam prijenos ne troši mobilne podatke.

📅 ISPRAVAK DATUMA FOTOGRAFIJA PO NAZIVU
Fotografije i videozapisi kopirani na novi mobitel, preuzeti iz WhatsAppa ili vraćeni iz sigurnosne kopije često dobiju današnji datum i u galeriji su na krivom mjestu. PhotoSync&fix čita datum iz naziva datoteke i vraća ispravan datum snimanja.
• Prepoznaje nazive kao IMG_20250705_105923.jpg, IMG-20261028-WA0014.jpg, VID_20250705_105923.mp4, Screenshot_2024-03-01…, PXL_…, i zapise s datumom na kraju.
• DDMM ili MMDD – vi birate kako tumačiti dvosmislene datume.
• Vlastiti oblici naziva (npr. GGGG-MM-DD_*).
• Samo fotografije, samo videozapisi ili oboje; odabir mapa i vremenskog intervala.
• Pregled prije promjene – mijenjate samo ono što odaberete. Upisuje datum u EXIF (JPG, PNG, WEBP) i MP4/MOV te postavlja datum izmjene.
• Radi i s tisućama datoteka.

🧹 ČIŠĆENJE DUPLIKATA
• Potpuno identične datoteke (SHA-256), čak i kad imaju različit naziv.
• Opcionalno: iste fotografije u drugoj veličini ili kvaliteti (npr. WhatsApp kopije) i slične fotografije za ručnu provjeru.
• Pravila koju kopiju zadržati: starija ili novija, veća, veća rezolucija, prioritet mapa (npr. DCIM/Camera ostaje, Download se briše prvi).
• U svakoj grupi uvijek ostaje barem jedna datoteka. Pregled s povećanjem, konačni popis i potvrda prije brisanja; brisanje u koš uz mogućnost oporavka.
• Skeniranje u pozadini, filtriranje po vremenskom intervalu.

🔒 PRIVATNOST
Sve se radi lokalno na vašim mobitelima. Aplikacija nema oglase, ne traži račun i ne šalje vaše podatke na internet ni na poslužitelje. Prijenos je zaštićen kodom koji se nikad ne šalje mrežom.

Hrvatski i engleski jezik. Android 11 ili noviji.
```

---

## 🇬🇧 English (en-US)

**App name (max 30) – 29 chars:**
```
PhotoSync&fix: Phone Transfer
```

**Short description (max 80) – 72 chars:**
```
Move photos to a new phone, fix wrong photo dates and remove duplicates.
```

**Full description (max 4000) – 2749 chars:**
```
New phone? PhotoSync&fix moves your photos, videos and other files from the old phone to the new one, restores the correct date of your photos and cleans up duplicates – no cable, no computer, no internet, no ads and no account.

📲 TRANSFER TO A NEW PHONE
• Fast Wi-Fi transfer: turn on the hotspot on one phone – either one – and connect the other to it. The same home Wi-Fi works too.
• A 4-digit code – the old phone finds the new one by itself, no addresses to type.
• Several parallel connections for maximum speed, large files first.
• Choose what to send: photos, videos, audio, documents, ZIP/RAR archives, APK files and installed apps (as APK).
• Pick a date range (e.g. only photos from 2025) and untick folders you do not want.
• Photos can go to the same folders as on the old phone (e.g. DCIM/Camera), to the default PhotoSync folder with a subfolder per type, or to a folder you choose.
• Keeps the original file dates, so the gallery shows photos under the right date.
• After the transfer you see exactly which items failed and resend them with one tap.
• Works with the screen off; skips files that already exist.
• The transfer itself uses no mobile data.

📅 FIX PHOTO DATES BY FILE NAME
Photos and videos copied to a new phone, saved from WhatsApp or restored from a backup often get today's date and end up in the wrong place in the gallery. PhotoSync&fix reads the date from the file name and restores the correct date taken.
• Recognises names like IMG_20250705_105923.jpg, IMG-20261028-WA0014.jpg, VID_20250705_105923.mp4, Screenshot_2024-03-01…, PXL_… and names with the date at the end.
• DDMM or MMDD – you choose how ambiguous dates are read.
• Your own name formats (e.g. YYYY-MM-DD_*).
• Photos only, videos only or both; choose folders and a date range.
• Preview before changing – only what you select is changed. Writes the date to EXIF (JPG, PNG, WEBP) and MP4/MOV and sets the modified date.
• Handles thousands of files.

🧹 DUPLICATE CLEANER
• Exact duplicates (SHA-256), even with different names.
• Optional: the same photo in another size or quality (e.g. WhatsApp copies) and similar photos for manual review.
• Rules for which copy to keep: older or newer, larger, higher resolution, folder priority (e.g. keep DCIM/Camera, delete from Download first).
• At least one file always stays in every group. Zoomable review, final list and confirmation before deleting; deleted files go to the trash and can be restored.
• Background scanning, date-range filter.

🔒 PRIVACY
Everything happens locally on your phones. No ads, no account, and your data is never sent to the internet or to any server. The transfer is protected by a code that is never sent over the network.

English and Croatian. Android 11 or newer.
```

---

## Kategorija, oznake i kontakt

| Polje | Vrijednost |
|---|---|
| Vrsta | Aplikacija |
| Kategorija | **Alati (Tools)** – alternativa: *Fotografija (Photography)* |
| Oznake (Play Console → Prisutnost u trgovini → Oznake, do 5) | odaberite one koje sustav ponudi, a najbliže su: prijenos datoteka, upravljanje fotografijama, čišćenje / čistač, upravitelj datoteka, sigurnosna kopija |
| E-pošta za kontakt | vaša e-pošta (vidljiva javno) |
| Web-stranica | neobavezno (npr. GitHub stranica projekta) |
| Pravila privatnosti (URL) | javni link na `PRIVACY_POLICY.md` (npr. GitHub → datoteka → *Raw*, ili GitHub Pages) |

## Ključne riječi (ASO)

Google Play nema polje za ključne riječi – rangiranje se temelji na **nazivu** (najjače), **kratkom opisu** i
**punom opisu**. Zato su u tim tekstovima prirodno upotrijebljeni izrazi koje ljudi pretražuju:

- **HR:** prijenos fotografija, prebaciti slike na novi mobitel, novi mobitel, kopiranje podataka, prijenos bez kabela,
  hotspot, Wi-Fi prijenos, ispravak datuma fotografija, krivi datum slike, WhatsApp slike datum, EXIF datum,
  duplikati, brisanje duplikata, čišćenje fotografija, oslobađanje prostora
- **EN:** phone transfer, transfer photos to new phone, copy my data, switch phone, file transfer without
  internet, Wi-Fi transfer, fix photo date, wrong photo date, WhatsApp photo date, EXIF date fixer, duplicate photo
  remover, duplicate cleaner, free up space

Savjeti:
- Ključne riječi ne ponavljajte umjetno (*keyword stuffing* je zabranjen i spušta rang).
- U nazivu i ikoni nisu dopuštene riječi tipa „najbolji”, „#1”, „besplatno”, cijene ni emotikoni.
- Nakon objave pratite *Statistika → Akvizicija iz trgovine → Pretraživanja* i prilagodite kratki opis prema stvarnim upitima.
- Dodajte i prijevode (npr. de, it, sl, sr, bs) – svaki jezik je zaseban unos za pretraživanje.

## Grafika

| Stavka | Datoteka / upute |
|---|---|
| Ikona 512 × 512 (PNG, 32-bit) | `store/icon-512.png` |
| Grafika s istaknutim sadržajem 1024 × 500 | `store/feature-graphic-1024x500.png` |
| Snimke zaslona mobitela (min. 2, preporuka 4–8, 1080 × 1920 ili 1080 × 2400) | snimite na mobitelu (gumb za uključivanje + stišavanje) |

Prijedlog snimaka zaslona i natpisa (natpis možete dodati u bilo kojem uređivaču slika):

| # | Zaslon | Natpis HR | Caption EN |
|---|---|---|---|
| 1 | Prijenos – početni zaslon s uputama | Prebacite sve na novi mobitel | Move everything to your new phone |
| 2 | Primanje – veliki kod i IP adresa | Samo 4 znamenke – bez kabela | Just 4 digits – no cable |
| 3 | Slanje u tijeku (brzina, napredak) | Brzo, i s ugašenim zaslonom | Fast, even with the screen off |
| 4 | Rezultat s gumbom „Pošalji ponovno neuspjele” | Ništa ne ostaje iza | Nothing gets left behind |
| 5 | Ispravak datuma – rezultati | Vratite fotografijama pravi datum | Give your photos the right date |
| 6 | Duplikati – grupa s usporedbom | Obrišite duplikate sigurno | Remove duplicates safely |

## Što napisati u bilješkama o izdanju (prva verzija)

- HR: `Prva verzija: prijenos na novi mobitel preko žarišne točke ili Wi-Fi-ja, ispravak datuma po nazivu, čišćenje duplikata.`
- EN: `First release: transfer to a new phone over hotspot or Wi-Fi, fix dates by file name, duplicate cleaner.`
